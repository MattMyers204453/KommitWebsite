//
//  HistoryViewController.swift
//  Kommit
//
//  Created by Jordan Hendley on 4/6/22.
//

import UIKit

/**
 A simple table to display History information
 */
class HistoryViewController: UIViewController{
    var kommit: Kommit?
    var histories = [History]()
    
    override func viewDidLoad() {
        if let histories = kommit?.histories {
            self.histories = histories.sortedArray(using: [NSSortDescriptor(key: "date", ascending: true, selector: #selector(NSDate.compare(_:)))]) as! [History]
        }
    }
}

extension HistoryViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return histories.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HistoryCell", for: indexPath)
        var content = UIListContentConfiguration.valueCell()
        if let font = UIFont(name: "Didot", size: 17) {
            content.textProperties.font = font
            content.secondaryTextProperties.font = font
        }
        let date = histories[indexPath.row].date!
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM dd, h:mm a"
        content.text = formatter.string(from: date)
        content.secondaryText = histories[indexPath.row].didSucceed ? "Pass" : "Fail"
        cell.contentConfiguration = content
        cell.backgroundColor = histories[indexPath.row].didSucceed ? UIColor.green.withAlphaComponent(0.1) : UIColor.red.withAlphaComponent(0.1)
        return cell
    }
    
    
}
