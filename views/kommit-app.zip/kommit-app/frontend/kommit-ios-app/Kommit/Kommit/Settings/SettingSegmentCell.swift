//
//  SettingSegmentCell.swift
//  Kommit
//
//  Created by Jordan Hendley on 2/14/22.
//

import Foundation
import UIKit

class SettingSegmentCell: UITableViewCell {
    
}
