//
//  SettingSwitchCell.swift
//  Kommit
//
//  Created by Jordan Hendley on 2/14/22.
//

import Foundation
import UIKit

class SettingSwitchCell: UITableViewCell {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var settingSwitch: UISwitch!
}
