//
//  SettingsViewController.swift
//  Kommit
//
//  Created by Jordan Hendley on 2/14/22.
//

import Foundation
import UIKit

/**
 A simple table view to display any settings we might have
 UNUSED
 */
class SettingsViewController: UITableViewController{
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = UITableViewCell()
        if indexPath.row == 0 {
            cell = tableView.dequeueReusableCell(withIdentifier: String(describing: SettingSwitchCell.self), for: indexPath)
        } else if indexPath.row == 1 {
            cell = tableView.dequeueReusableCell(withIdentifier: String(describing: SettingSegmentCell.self), for: indexPath)
        }
        
        return cell
    }
}
