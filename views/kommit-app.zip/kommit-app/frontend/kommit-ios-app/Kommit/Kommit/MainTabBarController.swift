//
//  MainTabBarController.swift
//  Kommit
//
//  Created by Jordan Hendley on 11/22/21.
//

import Foundation
import UIKit
import CoreData

protocol HasPersistentContainer{
    var container: NSPersistentContainer! { get set }
}

class MainTabBarController: UITabBarController, HasPersistentContainer{
    var container: NSPersistentContainer!
    
    /**
     Sets up first view and ensures that a persistent container is propogated down so that
     all the views underneath can access core data
     */
    override func viewDidLoad() {
        guard container != nil else {
            fatalError("This view needs a persistent container.")
        }
        if let viewControllers = viewControllers{
            for vc in viewControllers{
                if let navVC = vc as? UINavigationController{
                    if var view = navVC.visibleViewController as? HasPersistentContainer{
                        view.container = container
                    }
                }
            }
        }
    }
    
    /**
     Present the login view if no one has logged in yet
     */
    override func viewDidAppear(_ animated: Bool) {
        if (!UserDefaults.standard.bool(forKey: Defaults.loggedIn)){
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let loginVC = storyboard.instantiateViewController(withIdentifier: "LoginViewController")
            loginVC.modalPresentationStyle = .fullScreen
            present(loginVC, animated: false, completion: nil)
        }
    }
}
