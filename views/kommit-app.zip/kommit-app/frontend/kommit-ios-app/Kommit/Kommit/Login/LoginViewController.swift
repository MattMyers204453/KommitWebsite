//
//  LoginViewController.swift
//  Kommit
//
//  Created by Jordan Hendley on 1/22/22.
//

import UIKit

/**
 The login view controller. It also is used to register a new user.
 */
class LoginViewController: UIViewController {
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var topLabel: UILabel!
    @IBOutlet weak var userTypeButton: UIButton!
    var isNew = false
    
    override func viewDidLoad() {
        setLabels()
    }
    
    /**
     Either logs in a new user, or registers a new user and then logs in
     */
    @IBAction func didPressLoginBtn(_ sender: UIButton){
        if usernameField.text == "demo" {
            UserDefaults.standard.set(true, forKey: Defaults.loggedIn)
            DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
            }
        }
        var credentials = ["username":usernameField.text, "password":passwordField.text]
        if let data = UserDefaults.standard.data(forKey: Defaults.pushToken) {
            let pushToken = data.map { String(format: "%02x", $0) }.joined()
            credentials["devicetoken"] = pushToken
        }
        if let json = try? JSONSerialization.data(withJSONObject: credentials, options: .prettyPrinted) {
            let session = URLSession.shared
            if let url = URL(string: Constants.host + "login"){
                var request = URLRequest.init(url: url)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                let loginTask = session.uploadTask(with: request, from: json) { data, response, error in
                    if let response = response {
                        let status = (response as! HTTPURLResponse).statusCode
                        print("login status: %@", status)
                        if status == 200 {
                            if let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:Any] {
                                if let token = json["token"] as? String{
                                    print("login token: \(token)")
                                    UserDefaults.standard.set(token, forKey: Defaults.authToken)
                                }
                            }
                            UserDefaults.standard.set(true, forKey: Defaults.loggedIn)
                            DispatchQueue.main.async {
                                self.dismiss(animated: true, completion: nil)
                            }
                        } else {
                            DispatchQueue.main.async {
                                let alert = UIAlertController(title: "Authentication Failure", message: "Either your username or password was incorrect, double check and try again.", preferredStyle: .alert)
                                let action = UIAlertAction(title: "Ok", style: .default, handler: nil)
                                alert.addAction(action)
                                self.present(alert, animated: true, completion: nil)
                            }
                        }
                    }
                }
                if isNew {
                    if let json = try? JSONSerialization.data(withJSONObject: credentials, options: .prettyPrinted) {
                        let session = URLSession.shared
                        if let url = URL(string: Constants.host + "register"){
                            var request = URLRequest.init(url: url)
                            request.httpMethod = "POST"
                            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                            let registerTask = session.uploadTask(with: request, from: json) { data, response, error in
                                if let response = response {
                                    let status = (response as! HTTPURLResponse).statusCode
                                    print("register status: %@", status)
                                    if status == 200 {
                                        loginTask.resume()
                                    } else {
                                        DispatchQueue.main.async {
                                            let alert = UIAlertController(title: "Registration Failure", message: "This email likely already has an account, use another one.", preferredStyle: .alert)
                                            let action = UIAlertAction(title: "Ok", style: .default, handler: nil)
                                            alert.addAction(action)
                                            self.present(alert, animated: true, completion: nil)
                                        }
                                    }
                                }
                            }
                            registerTask.resume()
                        }
                    }
                } else {
                    loginTask.resume()
                }
            }
        }
    }
    
    /**
     Swaps between login and registration
     */
    @IBAction func didPressUserTypeButton(_ sender: UIButton){
        isNew = !isNew
        setLabels()
    }
    
    /**
     Changes the views based on login or registration
     */
    func setLabels() {
        let underlinedText = NSMutableAttributedString(string: "Click Here", attributes: [.underlineStyle:NSUnderlineStyle.single.rawValue])
        if isNew {
            topLabel.text = "Register"
            let standardText = NSMutableAttributedString(string: "Existing User? ")
            if let font = UIFont(name: "Didot", size: 17) {
                underlinedText.addAttribute(.font, value: font, range: NSRange(location: 0, length: underlinedText.length))
                standardText.addAttribute(.font, value: font, range: NSRange(location: 0, length: standardText.length))
            }
            let attributedText = NSMutableAttributedString()
            attributedText.append(standardText)
            attributedText.append(underlinedText)
            userTypeButton.setAttributedTitle(attributedText, for: .normal)
        } else {
            topLabel.text = "Kommit"
            let standardText = NSMutableAttributedString(string: "New User? ")
            if let font = UIFont(name: "Didot", size: 17) {
                underlinedText.addAttribute(.font, value: font, range: NSRange(location: 0, length: underlinedText.length))
                standardText.addAttribute(.font, value: font, range: NSRange(location: 0, length: standardText.length))
            }
            let attributedText = NSMutableAttributedString()
            attributedText.append(standardText)
            attributedText.append(underlinedText)
            userTypeButton.setAttributedTitle(attributedText, for: .normal)
        }
    }
    
    /**
     Checks to see if the username looks like an email, or is 'demo'
     Does not actually verify if the email exists
     If demo, the app will run offline
     */
    func isEmail(_ username: String?) -> Bool{
        if username == "demo" {
            return true
        }
        guard let username = username?.trimmingCharacters(in: .whitespacesAndNewlines) else {
            return false
        }

        guard let dataDetector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) else {
            return false
        }

        let range = NSMakeRange(0, NSString(string: username).length)
        let matches = dataDetector.matches(in: username, options: [], range: range)

        if matches.count == 1, matches.first?.url?.absoluteString.contains("mailto:") == true
        {
            return true
        }
        return false
    }
}

extension LoginViewController: UITextFieldDelegate {
    /**
     Waits to see if username and password have text before attempting login
     */
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if (isEmail(usernameField.text) && passwordField.text?.isEmpty == false){
            loginButton.isEnabled = true
        } else {
            loginButton.isEnabled = false
        }
        return true
    }
    
    /**
     Moves the keyboard based on which field Return was pressed in
     */
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == usernameField {
            passwordField.becomeFirstResponder()
        } else if textField == passwordField {
            passwordField.resignFirstResponder()
        }
        return true;
    }
}

