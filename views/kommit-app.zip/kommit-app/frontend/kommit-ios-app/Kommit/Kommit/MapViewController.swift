//
//  MapViewController.swift
//  Kommit
//
//  Created by Jordan Hendley on 12/3/21.
//

import UIKit
import MapKit

protocol HandleMapSearch {
    func dropPinZoomIn(placemark:MKPlacemark?)
}

/**
 A view controller used to display the Apple Maps api
 */
class MapViewController: UIViewController{
    
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    var resultSearchController: UISearchController? = nil
    var selectedPin:MKPlacemark? = nil
    weak var parentVC: EditKommitViewController!
    
    /**
     Ask for location permissions and set up the rest of the ui
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.requestLocation()
        
        let mapSearchTable = storyboard!.instantiateViewController(withIdentifier: String(describing: MapSearchResultsTableViewController.self)) as! MapSearchResultsTableViewController
        resultSearchController = UISearchController(searchResultsController: mapSearchTable)
        resultSearchController?.searchResultsUpdater = mapSearchTable
        mapSearchTable.mapView = mapView
        mapSearchTable.handleMapSearchDelegate = self
        
        let searchBar = resultSearchController!.searchBar
        searchBar.sizeToFit()
        searchBar.searchTextField.backgroundColor = UIColor(white: 0.2, alpha: 0.25)
        searchBar.searchTextField.attributedPlaceholder = NSAttributedString(
            string: "Search for places",
            attributes: [.foregroundColor: UIColor(red: 246/255, green: 215/255, blue: 254/255, alpha: 0.5)]
        )
        searchBar.searchTextField.textColor = UIColor(red: 246/255, green: 215/255, blue: 254/255, alpha: 1)
        navigationItem.titleView = resultSearchController?.searchBar
        resultSearchController?.hidesNavigationBarDuringPresentation = false
        resultSearchController?.obscuresBackgroundDuringPresentation = true
        definesPresentationContext = true
    }
    
    /**
     Send the information to the parent view controller
     */
    override func viewDidDisappear(_ animated: Bool) {
        parentVC.tableView.reloadData()
        parentVC.drawTopOfLock(true)
    }
}

extension MapViewController: CLLocationManagerDelegate{
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
        if status == .authorizedAlways || status == .authorizedWhenInUse {
                locationManager.requestLocation()
        }
    }
        
    /**
     Move the location to the user
     */
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first {
            let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
            let region = MKCoordinateRegion(center: location.coordinate, span: span)
            mapView.setRegion(region, animated: true)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("error:: \(error)")
    }

}

extension MapViewController: HandleMapSearch {
    /**
     Once a location is selected, save the information and move the map to display the location
     */
    func dropPinZoomIn(placemark:MKPlacemark?){
        // cache the pin
        selectedPin = placemark
        // clear existing pins
        mapView.removeAnnotations(mapView.annotations)
        parentVC.placemark = placemark
        guard let placemark = placemark else {
            return
        }
        let annotation = MKPointAnnotation()
        annotation.coordinate = placemark.coordinate
        annotation.title = placemark.name
        if let city = placemark.locality,
        let state = placemark.administrativeArea {
            annotation.subtitle = "\(city) \(state)"
        }
        mapView.addAnnotation(annotation)
        let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        let region = MKCoordinateRegion(center: placemark.coordinate, span: span)
        mapView.setRegion(region, animated: true)
    }
}
