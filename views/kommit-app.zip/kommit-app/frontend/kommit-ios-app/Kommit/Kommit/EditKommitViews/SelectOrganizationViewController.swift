//
//  SelectOrganizationViewController.swift
//  Kommit
//
//  Created by Jordan Hendley on 2/2/22.
//

import Foundation
import UIKit
import CoreData

/**
 A simple table to show existing Organzations
 */
class SelectOrganizationViewController: UIViewController, HasPersistentContainer{
    var container: NSPersistentContainer!
    @IBOutlet weak var tableView: UITableView!
    var organizations = [Organization]()
    var selectedOrg: Organization?
    weak var editVC: EditKommitViewController!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if var destination = segue.destination as? HasPersistentContainer {
            destination.container = container
        }
        if let destination = segue.destination as? NewOrganizationViewController {
            destination.editVC = editVC
        }
    }
    
    override func viewDidLoad() {
        reloadData()
    }
    
    func reloadData() {
        container.viewContext.performAndWait {
            let request = Organization.fetchRequest()
            let sort = NSSortDescriptor(key: "name", ascending: true)
            request.sortDescriptors = [sort]
            if let fetchedOrgs = try? container.viewContext.fetch(request){
                organizations = fetchedOrgs
            }
        }
        tableView.reloadData()
    }
}


extension SelectOrganizationViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return organizations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrgCell", for: indexPath)
        var content = UIListContentConfiguration.valueCell()
        if let font = UIFont(name: "Didot", size: 17) {
            content.textProperties.font = font
            content.secondaryTextProperties.font = font
        }
        content.text = organizations[indexPath.row].name
        content.secondaryText = organizations[indexPath.row].email
        cell.contentConfiguration = content
        if organizations[indexPath.row] == selectedOrg {
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        editVC.organization = organizations[indexPath.row]
        dismiss(animated: true, completion: nil)
        editVC.tableView.reloadData()
        editVC.drawHookOfLock(true)
    }
}
