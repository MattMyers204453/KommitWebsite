//
//  EditKommitViewController.swift
//  Kommit
//
//  Created by Jordan Hendley on 11/22/21.
//

import Foundation
import UIKit
import CoreData
import MapKit

/**
 The big cheese, this view controller is where a kommit is created
 */
class EditKommitViewController: UIViewController, HasPersistentContainer{
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lockView: UIView!
    @IBOutlet weak var saveButton: UIButton!
    let isNew = true
    var kommit: Kommit? = nil
    var container: NSPersistentContainer!
    
    var label: String?
    var location: Location?
    var frequency: Frequency?
    var bet: Decimal?
    var organization: Organization?
    var date: Date?
    
    var placemark: MKPlacemark?
    
    var hookShapeLayer: CAShapeLayer?
    var didDrawBottom = false
    var didDrawMiddle = false
    var didDrawTop = false
    var didDrawHook = false
    
    /**
     Sets up view controllers that will be displayed to ensure they have the appropriate information
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if var destination = segue.destination as? HasPersistentContainer{
            destination.container = container
        }
        if let destination = segue.destination as? MapViewController{
            destination.parentVC = self
            navigationItem.backButtonTitle = "Save"
        }
        if let destination = segue.destination as? KommitRepeatViewController {
            if frequency == nil{
                frequency = Frequency(context: container.viewContext)
                frequency?.component = 3
            }
            destination.frequency = frequency
        }
        if let destination = segue.destination as? SelectOrganizationViewController {
            
            destination.selectedOrg = organization
            destination.editVC = self
        }
        let button = UIBarButtonItem.init(title: "Save", style: .plain, target: nil, action: nil)
        if let font = UIFont(name: "Didot", size: 17) {
            button.setTitleTextAttributes([.font:font], for: .normal)
        }
        navigationItem.backBarButtonItem = button
    }
    
    /**
     Set up the UI based on whether a kommit exists or not
     */
    override func viewDidLoad() {
        if let kommit = kommit {
            label = kommit.label
            location = kommit.location
            bet = kommit.bet?.decimalValue
            organization = kommit.organization
            frequency = kommit.frequency
            date = kommit.date
            navigationItem.title = "Current Kommit"
            tableView.isUserInteractionEnabled = false
            drawLock()
        } else {
            label = "Set Label"
            bet = nil
            date = Date().addingTimeInterval(300)
        }
        if let font = UIFont(name: "Didot", size: 17) {
            self.navigationItem.rightBarButtonItem?.setTitleTextAttributes([.font:font], for: .normal)
        }
    }
    
    /**
     Draw the lock all at once
     */
    func drawLock(){
        saveButton.isHidden = true
        drawBottomOfLock(false)
        drawTopOfLock(false)
        drawMiddleOfLock(false)
        drawHookOfLock(false)
        closeHook(false, completion: nil)
    }
    
    /**
     Closes the lock, and then saves and sends the kommit up to the server
     */
    @IBAction func pressedSave(button: UIButton){
        button.isUserInteractionEnabled = false
        closeHook(true) { [self] in
            Thread.sleep(forTimeInterval: 1)
            container.viewContext.performAndWait {
                if kommit == nil {
                    kommit = Kommit(context: container.viewContext)
                    kommit?.kommitId = UUID()
                }
                if let kommit = kommit {
                    kommit.label = label
                    if let placemark = placemark {
                        if kommit.location == nil{
                            kommit.location = Location(context: container.viewContext)
                        }
                        kommit.location?.name = placemark.name
                        kommit.location?.latitude = placemark.coordinate.latitude
                        kommit.location?.longitude = placemark.coordinate.longitude
                    }
                    kommit.bet = bet as NSDecimalNumber?
                    kommit.organization = organization
                    kommit.frequency = frequency
                    kommit.date = date
                }
                container.saveViewContext()
            }
            uploadKommit()
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @objc func handleDatePicker(_ datePicker: UIDatePicker) {
        date = datePicker.date
    }
    
    func getLocationName()->String?{
        if let name = placemark?.name{
            return name
        }
        if let name = location?.name{
            return name
        }
        return nil
    }
    
    /**
     Uploads the kommit to the server
     */
    func uploadKommit(){
        DispatchQueue.global(qos: .userInitiated).async { [self] in
            let context = container.newBackgroundContext()
            if let id = kommit?.objectID{
                let kommit = context.object(with: id) as! Kommit
                var kommitDictionary = [
                    "kommit_id":kommit.kommitId?.uuidString,
                    "name":kommit.label,
                    "bet":kommit.bet?.decimalValue,
                    "location_name":kommit.location?.name,
                    "latitude":kommit.location?.latitude,
                    "longitude":kommit.location?.longitude,
                    "component":kommit.frequency?.component,
                    "days_of_the_week":kommit.frequency?.daysOfTheWeek,
                    "duration":kommit.frequency?.duration,
                    "organization_id":kommit.organization?.organizationId?.uuidString,
                    "user_id":"42c00c4f-8154-11ec-a92c-d85ed30193f8",
                ] as [String : Any?]
                let date = kommit.date ?? Date()
                let iso = ISO8601DateFormatter()
                iso.timeZone = TimeZone(identifier: "UTC")
                kommitDictionary["date"] = iso.string(from:date)
                
                if let json = try? JSONSerialization.data(withJSONObject: kommitDictionary, options: .prettyPrinted) {
                    let session = URLSession.shared
                    if let url = URL(string: Constants.host + "kommit"){
                        var request = URLRequest.init(url: url)
                        request.httpMethod = "POST"
                        request.setValue(UserDefaults.standard.string(forKey: Defaults.authToken)!, forHTTPHeaderField: "Token")
                        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                        let task = session.uploadTask(with: request, from: json) { data, response, error in
                            if let response = response {
                                print("status: %@", (response as! HTTPURLResponse).statusCode)
                                if let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:Any] {
                                    if let idString = json["kommit_id"] as? String, let kommitId = UUID(uuidString: idString){
                                        context.perform {
                                            kommit.kommitId = kommitId
                                            self.container.saveContext(context)
                                        }
                                    }
                                }
                            }
                        }
                        task.resume()
                    }
                }
                
            }
        }
    }
}

/**
 Most of these simply serve to update the table with the appropriate information
 */
extension EditKommitViewController: UITableViewDelegate, UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0{
            return "Details"
        } else {
            return "Scheduling"
        }
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if section == 0{
            let view = UIView()
            view.backgroundColor = UIColor.kommitBlue
            return view
        }
        return nil
    }

    public func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return 4
        } else {
            return 2
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell
        if indexPath.section == 0{
            if indexPath.row == 1 {
                cell = tableView.dequeueReusableCell(withIdentifier: "KommitMapCell", for: indexPath)
            } else if indexPath.row == 3{
                cell = tableView.dequeueReusableCell(withIdentifier: "KommitOrgCell", for: indexPath)
            } else {
                cell = tableView.dequeueReusableCell(withIdentifier: "KommitCell", for: indexPath)
            }
            var content = UIListContentConfiguration.valueCell()
            if let font = UIFont(name: "Didot", size: 17) {
                content.textProperties.font = font
                content.secondaryTextProperties.font = font
            }
            if (indexPath.row == 0){
                content.text = "Label"
                content.secondaryText = label
            } else if (indexPath.row == 1){
                content.text = "Location"
                content.secondaryText = getLocationName()
            } else if (indexPath.row == 2){
                content.text = "Bet"
                if let bet = bet{
                    content.secondaryText = "$" + bet.formatted(.number.precision(.fractionLength(2)))
                } else {
                    content.secondaryText = "$_.__"
                }
            }else if (indexPath.row == 3){
                content.text = "Organization"
                content.secondaryText = organization?.name
            }
            cell.contentConfiguration = content
        } else {
            if indexPath.row == 0{
                let dateCell = tableView.dequeueReusableCell(withIdentifier: String(describing: KommitDateCell.self), for: indexPath) as! KommitDateCell
                dateCell.datePicker.minimumDate = Date()
                dateCell.datePicker.date = date ?? Date().addingTimeInterval(300)
                dateCell.datePicker.addTarget(self, action: #selector(handleDatePicker), for: .valueChanged)
                cell = dateCell
            } else if indexPath.row == 1 {
                cell = tableView.dequeueReusableCell(withIdentifier: "KommitRepeatCell", for: indexPath)
                var content = UIListContentConfiguration.valueCell()
                if let font = UIFont(name: "Didot", size: 17) {
                    content.textProperties.font = font
                    content.secondaryTextProperties.font = font
                }
                if (indexPath.row == 1){
                    content.text = "Repeat"
                    if frequency == nil || frequency?.component == 3 {
                        content.secondaryText = "Never"
                    } else if frequency?.component == 2{
                        content.secondaryText = "Daily"
                    } else if frequency?.component == 1{
                        content.secondaryText = "Weekly"
                    } else if frequency?.component == 0{
                        content.secondaryText = "Monthly"
                    }
                }
                cell.contentConfiguration = content
            } else {
                cell = UITableViewCell()
            }
        }
            
        return cell;
    }
    
    /**
     Displays the input view for the Label and Bet fields
     */
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var title: String?
        if (indexPath.row == 0){
            title = "Label"
        } else if (indexPath.row == 1){
            return
        } else if (indexPath.row == 2){
            title = "Bet"
        } else if (indexPath.row == 3){
            return
        }
        let ac = UIAlertController.init(title: title, message: nil, preferredStyle: .alert)
        ac.addTextField{ textField in
            textField.textAlignment = .center
            if (indexPath.row == 2){
                textField.keyboardType = .decimalPad
            }
        }
            
        let submitAction = UIAlertAction(title: "Submit", style: .default) {
            [weak self, weak ac] _ in
            guard let answer = ac?.textFields?[0].text else { return }
            
            if (indexPath.row == 0){
                self?.label = answer
                self?.drawBottomOfLock(true)
            } else if (indexPath.row == 2){
                self?.bet = Decimal(string: answer)
                self?.drawMiddleOfLock(true)
            }
            tableView.reloadData()
        }
        ac.addAction(submitAction)
        present(ac, animated: true)
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        guard let header = view as? UITableViewHeaderFooterView else { return }
        header.textLabel?.font = UIFont(name: "Didot", size: 17)
        header.textLabel?.sizeToFit()
    }
}

/**
 These methods all draw different portions of the lock
 */
extension EditKommitViewController: CAAnimationDelegate {
    
    func drawBottomOfLock(_ withAnimation: Bool) {
        didDrawBottom = true
        let leftX = lockView.bounds.width / 2 - 80
        let rightX = lockView.bounds.width / 2 + 80
        let middleY = lockView.bounds.height * 1/2
        let bottomY = lockView.bounds.height - 10
        let start = UIBezierPath()
        start.move(to: CGPoint(x: leftX, y: middleY))
        start.addLine(to: CGPoint(x: leftX, y: middleY))
                
        start.close()
                
        let shapeLayer = CAShapeLayer()
        lockView.layer.addSublayer(shapeLayer)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.lineWidth = 8
        shapeLayer.path = start.cgPath
        
        let animationLeft = CABasicAnimation(keyPath: "path")
        if withAnimation {
            animationLeft.duration = 0.5
        }

        let left = UIBezierPath()
        left.move(to: CGPoint(x: leftX, y: middleY))
        left.addLine(to: CGPoint(x: leftX, y: bottomY))
        
        animationLeft.toValue = left.cgPath
        animationLeft.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        animationLeft.fillMode = CAMediaTimingFillMode.forwards
        animationLeft.isRemovedOnCompletion = false

        shapeLayer.add(animationLeft, forKey: nil)
        
        
        let animationBottom = CABasicAnimation(keyPath: "path")
        if withAnimation {
            animationBottom.duration = 0.5
            animationBottom.beginTime = CACurrentMediaTime() + 0.5
        }

        let bottom = UIBezierPath()
        bottom.move(to: CGPoint(x: leftX, y: middleY))
        bottom.addLine(to: CGPoint(x: leftX, y: bottomY))
        bottom.addLine(to: CGPoint(x: rightX, y: bottomY))
        
        animationBottom.toValue = bottom.cgPath
        animationBottom.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        animationBottom.fillMode = CAMediaTimingFillMode.forwards
        animationBottom.isRemovedOnCompletion = false

        shapeLayer.add(animationBottom, forKey: nil)
        
        let animationRight = CABasicAnimation(keyPath: "path")
        if withAnimation {
            animationRight.duration = 0.5
            animationRight.beginTime = CACurrentMediaTime() + 1
        }

        let right = UIBezierPath()
        right.move(to: CGPoint(x: leftX, y: middleY))
        right.addLine(to: CGPoint(x: leftX, y: bottomY))
        right.addLine(to: CGPoint(x: rightX, y: bottomY))
        right.addLine(to: CGPoint(x: rightX, y: middleY))
        
        animationRight.toValue = right.cgPath
        animationRight.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        animationRight.fillMode = CAMediaTimingFillMode.forwards
        animationRight.isRemovedOnCompletion = false

        shapeLayer.add(animationRight, forKey: nil)
        showSave()
    }
    
    func drawTopOfLock(_ withAnimation: Bool) {
        didDrawTop = true
        let leftX = lockView.bounds.width / 2 - 80
        let rightX = lockView.bounds.width / 2 + 80
        let middleY = lockView.bounds.height * 1/2
        let topY = lockView.bounds.height * 1/4
        let start = UIBezierPath()
        start.move(to: CGPoint(x: leftX, y: middleY))
        start.addLine(to: CGPoint(x: leftX, y: middleY))
                
        start.close()
                
        let shapeLayer = CAShapeLayer()
        lockView.layer.addSublayer(shapeLayer)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.lineWidth = 8
        shapeLayer.path = start.cgPath
        
        let animationLeft = CABasicAnimation(keyPath: "path")
        if withAnimation {
            animationLeft.duration = 0.5
        }

        let left = UIBezierPath()
        left.move(to: CGPoint(x: leftX, y: middleY))
        left.addLine(to: CGPoint(x: leftX, y: topY))
        
        animationLeft.toValue = left.cgPath
        animationLeft.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        animationLeft.fillMode = CAMediaTimingFillMode.forwards
        animationLeft.isRemovedOnCompletion = false

        shapeLayer.add(animationLeft, forKey: nil)
        
        
        let animationBottom = CABasicAnimation(keyPath: "path")
        if withAnimation {
            animationBottom.duration = 0.5
            animationBottom.beginTime = CACurrentMediaTime() + 0.5
        }

        let bottom = UIBezierPath()
        bottom.move(to: CGPoint(x: leftX, y: middleY))
        bottom.addLine(to: CGPoint(x: leftX, y: topY))
        bottom.addLine(to: CGPoint(x: rightX, y: topY))
        
        animationBottom.toValue = bottom.cgPath
        animationBottom.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        animationBottom.fillMode = CAMediaTimingFillMode.forwards
        animationBottom.isRemovedOnCompletion = false

        shapeLayer.add(animationBottom, forKey: nil)
        
        let animationRight = CABasicAnimation(keyPath: "path")
        if withAnimation {
            animationRight.duration = 0.5
            animationRight.beginTime = CACurrentMediaTime() + 1
        }

        let right = UIBezierPath()
        right.move(to: CGPoint(x: leftX, y: middleY))
        right.addLine(to: CGPoint(x: leftX, y: topY))
        right.addLine(to: CGPoint(x: rightX, y: topY))
        right.addLine(to: CGPoint(x: rightX, y: middleY))
        
        animationRight.toValue = right.cgPath
        animationRight.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        animationRight.fillMode = CAMediaTimingFillMode.forwards
        animationRight.isRemovedOnCompletion = false

        shapeLayer.add(animationRight, forKey: nil)
        showSave()
    }
    
    func drawMiddleOfLock(_ withAnimation: Bool) {
        didDrawMiddle = true
        let leftX = lockView.bounds.width / 2 - 80
        let rightX = lockView.bounds.width / 2 + 80
        let bottomY = lockView.bounds.height - 10
        let topY = lockView.bounds.height * 1/4
        let ySpacing = (bottomY - topY) / 5
        
        var currentYSpacing = topY + ySpacing
        for i in 0...3 {
            if i == 1 {
                let shapeLayerLeft = CAShapeLayer()
                lockView.layer.addSublayer(shapeLayerLeft)
                shapeLayerLeft.fillColor = UIColor.clear.cgColor
                shapeLayerLeft.strokeColor = UIColor.black.cgColor
                shapeLayerLeft.lineWidth = 4
                let startLeft = UIBezierPath()
                startLeft.move(to: CGPoint(x: leftX, y: currentYSpacing))
                startLeft.addLine(to: CGPoint(x: leftX, y: currentYSpacing))
                startLeft.close()
                shapeLayerLeft.path = startLeft.cgPath
                    
                let animationLeft = CABasicAnimation(keyPath: "path")
                if withAnimation {
                    animationLeft.duration = 0.5
                }

                let end = UIBezierPath()
                end.move(to: CGPoint(x: leftX, y: currentYSpacing))
                end.addLine(to: CGPoint(x: leftX + 50, y: currentYSpacing))
                    
                animationLeft.toValue = end.cgPath
                animationLeft.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
                animationLeft.fillMode = CAMediaTimingFillMode.forwards
                animationLeft.isRemovedOnCompletion = false

                shapeLayerLeft.add(animationLeft, forKey: nil)
                
                let shapeLayerRight = CAShapeLayer()
                lockView.layer.addSublayer(shapeLayerRight)
                shapeLayerRight.fillColor = UIColor.clear.cgColor
                shapeLayerRight.strokeColor = UIColor.black.cgColor
                shapeLayerRight.lineWidth = 4
                let startRight = UIBezierPath()
                startRight.move(to: CGPoint(x: rightX, y: currentYSpacing))
                startRight.addLine(to: CGPoint(x: rightX, y: currentYSpacing))
                startRight.close()
                shapeLayerRight.path = startRight.cgPath
                        
                let animationRight = CABasicAnimation(keyPath: "path")
                if withAnimation {
                    animationRight.duration = 0.5
                }

                let endRight = UIBezierPath()
                endRight.move(to: CGPoint(x: rightX, y: currentYSpacing))
                endRight.addLine(to: CGPoint(x: rightX - 50, y: currentYSpacing))
                        
                animationRight.toValue = endRight.cgPath
                animationRight.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
                animationRight.fillMode = CAMediaTimingFillMode.forwards
                animationRight.isRemovedOnCompletion = false

                shapeLayerRight.add(animationRight, forKey: nil)
                currentYSpacing += ySpacing
                continue
            }
            var startX = leftX
            var endX = rightX
            if i == 2 {
                startX = rightX
                endX = leftX
            }
            let shapeLayer = CAShapeLayer()
            lockView.layer.addSublayer(shapeLayer)
            shapeLayer.fillColor = UIColor.clear.cgColor
            shapeLayer.strokeColor = UIColor.black.cgColor
            shapeLayer.lineWidth = 4
            let start = UIBezierPath()
            start.move(to: CGPoint(x: startX, y: currentYSpacing))
            start.addLine(to: CGPoint(x: startX, y: currentYSpacing))
            start.close()
            shapeLayer.path = start.cgPath
                
            let animation = CABasicAnimation(keyPath: "path")
            if withAnimation {
                animation.duration = 0.5
            }

            let end = UIBezierPath()
            end.move(to: CGPoint(x: startX, y: currentYSpacing))
            end.addLine(to: CGPoint(x: endX, y: currentYSpacing))
                
            animation.toValue = end.cgPath
            animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
            animation.fillMode = CAMediaTimingFillMode.forwards
            animation.isRemovedOnCompletion = false

            shapeLayer.add(animation, forKey: nil)
            currentYSpacing += ySpacing
        }
        showSave()
    }
    
    func drawHookOfLock(_ withAnimation: Bool) {
        didDrawHook = true
        let leftX = lockView.bounds.width / 2 - 40
        let middleX = lockView.bounds.width / 2
        let rightX = lockView.bounds.width / 2 + 40
        let bottomY = lockView.bounds.height * 1/4
        let middleY:CGFloat = 0
        
        let shapeLayer = CAShapeLayer()
        hookShapeLayer = shapeLayer
        lockView.layer.addSublayer(shapeLayer)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.lineWidth = 8
        let start = UIBezierPath()
        start.move(to: CGPoint(x: rightX, y: bottomY))
        start.addLine(to: CGPoint(x: rightX, y: bottomY))
        start.close()
        shapeLayer.path = start.cgPath
        
        let animation = CABasicAnimation(keyPath: "path")
        if withAnimation {
            animation.duration = 0.5
        }
        
        let end = UIBezierPath()
        end.move(to: CGPoint(x: rightX, y: bottomY))
        end.addLine(to: CGPoint(x: rightX, y: middleY))
        end.addArc(withCenter: CGPoint(x: middleX, y: middleY), radius: rightX - middleX, startAngle: 0, endAngle: CGFloat.pi, clockwise: false)
        end.addLine(to: CGPoint(x: leftX, y: middleY + 20))
        
        animation.toValue = end.cgPath
        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        animation.fillMode = CAMediaTimingFillMode.forwards
        animation.isRemovedOnCompletion = false
        
        shapeLayer.add(animation, forKey: nil)
        showSave()
    }
    
    func showSave() {
        if didDrawTop && didDrawMiddle && didDrawBottom && didDrawHook {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveLinear) {
                self.saveButton.alpha = 1
            } completion: { finished in
                if finished {
                    self.saveButton.isUserInteractionEnabled = true
                }
            }

        }
    }
    
    func closeHook(_ withAnimation: Bool, completion: (() -> Void)?) {
        CATransaction.begin()
        let leftX = lockView.bounds.width / 2 - 40
        let middleX = lockView.bounds.width / 2
        let rightX = lockView.bounds.width / 2 + 40
        let bottomY = lockView.bounds.height * 1/4
        let middleY = bottomY - 20
        
        if let shapeLayer = hookShapeLayer {
            let animation = CABasicAnimation(keyPath: "path")
            if withAnimation {
                animation.duration = 0.5
            }
            
            let end = UIBezierPath()
            end.move(to: CGPoint(x: rightX, y: bottomY))
            end.addLine(to: CGPoint(x: rightX, y: middleY))
            end.addArc(withCenter: CGPoint(x: middleX, y: middleY), radius: rightX - middleX, startAngle: 0, endAngle: CGFloat.pi, clockwise: false)
            end.addLine(to: CGPoint(x: leftX, y: bottomY))
            
            animation.toValue = end.cgPath
            animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
            animation.fillMode = CAMediaTimingFillMode.forwards
            animation.isRemovedOnCompletion = false
            if let completion = completion {
                CATransaction.setCompletionBlock(completion)
            }
            shapeLayer.add(animation, forKey: nil)
        }
        CATransaction.commit()
    }
}
