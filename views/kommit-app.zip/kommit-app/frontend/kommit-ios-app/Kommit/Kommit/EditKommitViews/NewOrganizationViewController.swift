//
//  NewOrganizationViewController.swift
//  Kommit
//
//  Created by Jordan Hendley on 2/2/22.
//

import Foundation
import UIKit
import CoreData

/**
 A view controller with a name and email field to make new organizations
 */
class NewOrganizationViewController: UIViewController, HasPersistentContainer{
    var container: NSPersistentContainer!
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var saveBtn: UIButton!
    weak var editVC: EditKommitViewController!
    
    @IBAction func didPressSaveBtn(_ sender: UIButton){
        uploadOrganization(nameField.text, emailField.text)
    }
    
    /**
     Send the organization up to the server
     */
    func uploadOrganization(_ name: String?, _ email: String?){
        DispatchQueue.global(qos: .userInitiated).async { [self] in
            let orgDictionary = [
                "paypal_email":email,
                "label":name,
            ] as [String : Any?]
            if let json = try? JSONSerialization.data(withJSONObject: orgDictionary, options: .prettyPrinted) {
                let session = URLSession.shared
                if let url = URL(string: Constants.host + "organization"){
                    var request = URLRequest.init(url: url)
                    request.httpMethod = "POST"
                    request.setValue(UserDefaults.standard.string(forKey: Defaults.authToken) ?? "", forHTTPHeaderField: "Token")
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    let task = session.uploadTask(with: request, from: json) { data, response, error in
                        if let response = response {
                            print("status: %@", (response as! HTTPURLResponse).statusCode)
                            if let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:Any] {
                                if let idString = json["organization_id"] as? String{
                                    DispatchQueue.main.async { [self] in
                                        container.viewContext.performAndWait {
                                            if let orgId = UUID(uuidString: idString){
                                                let org = Organization(context: container.viewContext)
                                                org.name = nameField.text
                                                org.email = emailField.text
                                                org.organizationId = orgId
                                                container.saveContext(container.viewContext)
                                                
                                                editVC.organization = org
                                                editVC.dismiss(animated: true) {
                                                    self.editVC.tableView.reloadData()
                                                    self.editVC.drawHookOfLock(true)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    task.resume()
                }
            }
        }
    }
}
