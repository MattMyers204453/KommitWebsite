//
//  KommitRepeatViewController.swift
//  Kommit
//
//  Created by Jordan Hendley on 1/15/22.
//

import UIKit

/**
 A view controller to set whether or not a kommit repeats, and how often
 */
class KommitRepeatViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableBackgroundView: UIView!
    @IBOutlet weak var upButton: UIButton!
    @IBOutlet weak var downButton: UIButton!
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var summaryLabel: UILabel!
    @IBOutlet weak var componentSegments: UISegmentedControl!
    var selectedDays: Days = []
    var frequency: Frequency!
    
    override func viewDidLoad() {
        componentSegments.selectedSegmentIndex = Int(frequency.component)
        if let font = UIFont(name: "Didot", size: 17) {
            componentSegments.setTitleTextAttributes([.font:font], for: .normal)
            componentSegments.setTitleTextAttributes([.font:font], for: .selected)
        }
        selectedDays = Days(rawValue: frequency.daysOfTheWeek)
        loadData()
    }
    
    @IBAction func didSelectUpButton(_ sender: Any) {
        frequency.duration += 1
        downButton.isEnabled = true
        loadData()
    }
    
    @IBAction func didSelectDownButton(_ sender: Any) {
        frequency.duration -= 1
        loadData()
    }
    
    /**
     Adjust the UI based on which time frame was selected
     */
    @IBAction func componentValueChanged(_ sender: UISegmentedControl) {
        frequency.component = Int16(sender.selectedSegmentIndex)
        upButton.isEnabled = true
        numberLabel.isEnabled = true
        loadData()
    }
    
    func loadData(){
        if componentSegments.selectedSegmentIndex == 3 {
            downButton.isEnabled = false
            upButton.isEnabled = false
            numberLabel.isEnabled = false
            summaryLabel.text = "Never repeats"
            return
        }
        if componentSegments.selectedSegmentIndex == 1{
            tableView.isHidden = false
            tableBackgroundView.isHidden = false
        } else {
            tableView.isHidden = true
            tableBackgroundView.isHidden = true
        }
        numberLabel.text = String(frequency.duration)
        
        let summary = "Repeats every "
        var numberString = ""
        var pluralString = ""
        if frequency.duration > 1 {
            numberString = "\(frequency.duration) "
            pluralString = "s"
        }
        var component = ""
        
        if componentSegments.selectedSegmentIndex == 0 {
            component = "month\(pluralString)"
        } else if componentSegments.selectedSegmentIndex == 1 {
            component = "week\(pluralString) on the following days:"
        } else if componentSegments.selectedSegmentIndex == 2 {
            component = "day\(pluralString)"
        }
        
        summaryLabel.text = summary + numberString + component
        
        
        if frequency.duration == 1 {
            downButton.isEnabled = false
        } else {
            downButton.isEnabled = true
        }
        
        self.view.setNeedsDisplay()
    }
    
}

/**
 A table listing the days of the week if week is selected as the time frame
 */
extension KommitRepeatViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        7
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "KommitDailyCell", for: indexPath)
        var content = UIListContentConfiguration.valueCell()
        if let font = UIFont(name: "Didot", size: 17) {
            content.textProperties.font = font
        }
        if (indexPath.row == 0){
            content.text = "Sunday"
        } else if (indexPath.row == 1){
            content.text = "Monday"
        } else if (indexPath.row == 2){
            content.text = "Tuesday"
        } else if (indexPath.row == 3){
            content.text = "Wednesday"
        } else if (indexPath.row == 4){
            content.text = "Thursday"
        } else if (indexPath.row == 5){
            content.text = "Friday"
        } else if (indexPath.row == 6){
            content.text = "Saturday"
        }
        cell.contentConfiguration = content
        if (selectedDays.contains(Days(rawValue: 1 << indexPath.row))){
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }
        if selectedDays.count() > 1 {
            frequency.duration = 1
            loadData()
            downButton.isEnabled = false
            upButton.isEnabled = false
        } else {
            upButton.isEnabled = true
            downButton.isEnabled = true
            loadData()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let day = Days(rawValue: 1 << indexPath.row)
        if selectedDays.contains(day){
            selectedDays.remove(day)
        } else {
            selectedDays.insert(day)
        }
        frequency.daysOfTheWeek = selectedDays.rawValue
        tableView.reloadData()
    }
    
}

/**
 A helper struct to know which days of the week are selected if the time frame is week
 */
struct Days: OptionSet {
    
    let rawValue: Int16
    
    static let sunday       = Days(rawValue: 1 << 0)
    static let monday       = Days(rawValue: 1 << 1)
    static let tuesday      = Days(rawValue: 1 << 2)
    static let wednesday    = Days(rawValue: 1 << 3)
    static let thursday     = Days(rawValue: 1 << 4)
    static let friday       = Days(rawValue: 1 << 5)
    static let saturday     = Days(rawValue: 1 << 6)
    
    func count() -> Int {
        var days = 0
        if self.contains(.sunday){
            days += 1
        }
        if self.contains(.monday){
            days += 1
        }
        if self.contains(.tuesday){
            days += 1
        }
        if self.contains(.wednesday){
            days += 1
        }
        if self.contains(.thursday){
            days += 1
        }
        if self.contains(.friday){
            days += 1
        }
        if self.contains(.saturday){
            days += 1
        }
        return days
    }
    
    func calendarValue() -> Int {
        if self.contains(.sunday){
            return 1
        }
        if self.contains(.monday){
            return 2
        }
        if self.contains(.tuesday){
            return 3
        }
        if self.contains(.wednesday){
            return 4
        }
        if self.contains(.thursday){
            return 5
        }
        if self.contains(.friday){
            return 6
        }
        if self.contains(.saturday){
            return 7
        }
        return 0
    }
}
