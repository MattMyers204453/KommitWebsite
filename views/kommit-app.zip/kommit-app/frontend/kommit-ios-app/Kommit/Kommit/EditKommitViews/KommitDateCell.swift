//
//  KommitDateCell.swift
//  Kommit
//
//  Created by Jordan Hendley on 1/15/22.
//

import UIKit

/**
 A custom UITableViewCell with a date picker inside.
 The parent table handles any changes in values
 */
class KommitDateCell: UITableViewCell{
    @IBOutlet weak var datePicker: UIDatePicker!
}
