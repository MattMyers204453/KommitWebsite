//
//  HomeCell.swift
//  Kommit
//
//  Created by Jordan Hendley on 3/26/22.
//

import Foundation
import UIKit
import SwiftUI

/**
 A cell to display kommit information on home
 */
class HomeCell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var historyButton: UIButton!
    weak var home: HomeViewController?
    weak var kommit: Kommit?
    
    @IBAction func didSelectHistoryButton(sender: UIButton){
        if let home = home, let kommit = kommit {
            home.selectedKommit = kommit
        }
    }
}
