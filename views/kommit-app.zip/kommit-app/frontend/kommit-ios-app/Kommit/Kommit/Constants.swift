//
//  Constants.swift
//  Kommit
//
//  Created by Jordan Hendley on 11/27/21.
//

import Foundation
import UIKit

/**
 Used in places that normally take in strings
 */
struct Constants {
    //public static let host = "http://jordans-macbook-pro.local:8080/"
    public static let host = "http://54.237.48.195:8080/"
    //public static let paypalHost = "http://jordans-macbook-pro.local:3000/"
    public static let paypalHost = "https://kommit-paypal-server.herokuapp.com/"
    public static let paymentTokenizationKeySandbox = "sandbox_yk4gqg4k_fyjwsfk7c5mxdyfr"
}

/**
 Similar to Constants, this is specifically used for UserDefaults names
 */
struct Defaults {
    public static let paymentMethod = "paymentMethod"
    public static let loggedIn = "loggedIn"
    public static let authToken = "authToken"
    public static let pushToken = "pushToken"
}

extension UIColor{
    static let kommitBlue = UIColor(red: 112/255, green: 151/255, blue: 255/255, alpha: 1)
}
