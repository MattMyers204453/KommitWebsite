//
//  AppDelegate.swift
//  Kommit
//
//  Created by Jordan Hendley on 11/15/21.
//

import UIKit
import CoreData
import CoreLocation

@main
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    var kommitId = ""


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        // set the type as sound or badge
        center.requestAuthorization(options: [.sound,.alert,.badge]) { (granted, error) in
            if granted {
                print("Notification Enabled Successfully")
            }else{
                print("Some Error Occure")
            }
        }
        application.registerForRemoteNotifications()
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (_ options:UNNotificationPresentationOptions) -> Void)
    {
        print("Handle push from foreground")
        print("\(notification.request.content.userInfo)")
        handleNotification(notification.request.content.userInfo)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response:UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void)
    {
        print("Handle push from background or closed")
        print("\(response.notification.request.content.userInfo)")
        handleNotification(response.notification.request.content.userInfo)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        print(deviceToken.map { String(format: "%02x", $0) }.joined())
        UserDefaults.standard.set(deviceToken, forKey: Defaults.pushToken)
    }

    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
        */
        let container = NSPersistentContainer(name: "Kommit")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                 
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Saving support

    func saveContext () {
        persistentContainer.saveViewContext()
    }
 

}

extension NSPersistentContainer {
    func saveViewContext(){
        //(UIApplication.shared.delegate as? AppDelegate)?.saveContext()
        let context = self.viewContext
        saveContext(context)
    }
    
    func saveContext(_ context: NSManagedObjectContext){
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}

/**
 This is extended to organize my methods out from the system methods
 */
extension AppDelegate {
    /**
     If we get a push notification, check the location
     */
    func handleNotification(_ notification: [AnyHashable:Any]){
        if let id = notification["KID"] as? String {
            kommitId = id
        }
        let locationManager = CLLocationManager()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
    }
}


extension AppDelegate: CLLocationManagerDelegate {
    /**
     Communicate with the server to see if the current location is within the kommit referenced
     in the push notification, and create a History object to record if it was a success or failure
     */
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        var latitude:Double = 0
        var longitude:Double = 0
        if let location = locations.last {
            latitude = location.coordinate.latitude
            longitude = location.coordinate.longitude
        }
        
        
        let iso = ISO8601DateFormatter()
        iso.timeZone = .current
        let checkInDictionary = [
            "user_id":"42c00c4f-8154-11ec-a92c-d85ed30193f8",
            "latitude":latitude,
            "longitude":longitude,
            "date":iso.string(from:Date()),
        ] as [String : Any?]
        
         
        if let json = try? JSONSerialization.data(withJSONObject: checkInDictionary, options: .prettyPrinted) {
            if let checkInURL = URL(string: "\(Constants.host)kommit/\(kommitId)/check-in"){
                var checkInRequest = URLRequest(url: checkInURL)
                checkInRequest.httpMethod = "POST"
                checkInRequest.setValue(UserDefaults.standard.string(forKey: Defaults.authToken)!, forHTTPHeaderField: "Token")
                checkInRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
                let task = URLSession.shared.uploadTask(with: checkInRequest, from: json) { [self] data, response, error in
                    if let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:Any] {
                        if let result = json["status"] as? String {
                            print("result: \(result)")
                            let context = self.persistentContainer.newBackgroundContext()
                            var didSucceed: Bool? = nil
                            if result == "failed" {
                                didSucceed = false
                                let captureURL = URL(string: "\(Constants.host)capture")!
                                var request = URLRequest(url: captureURL)
                                request.httpMethod = "POST"
                                request.setValue(UserDefaults.standard.string(forKey: Defaults.authToken)!, forHTTPHeaderField: "Token")
                                let kommitDictionary = ["kommit_id":kommitId]
                                if let json = try? JSONSerialization.data(withJSONObject: kommitDictionary, options: .prettyPrinted) {
                                    request.httpBody = json
                                }
                                URLSession.shared.dataTask(with: request) { (data, response, error) -> Void in
                                    print("HERE2")
                                }.resume()
                            } else if result == "complete" {
                                didSucceed = true
                            }
                            context.perform { [self] in
                                let fetch = Kommit.fetchRequest()
                                let kommitUUID = UUID(uuidString: kommitId)!
                                fetch.predicate = NSPredicate(format:"kommitId = %@", kommitUUID as CVarArg)
                                if let kommit = try? context.fetch(fetch).first {
                                    if let didSucceed = didSucceed {
                                        let history = History(context: context)
                                        history.didSucceed = didSucceed
                                        history.date = Date()
                                        history.kommit = kommit
                                        kommit.successes += 1
                                        
                                        if let frequency = kommit.frequency {
                                            let calendar = Calendar.current
                                            if frequency.component == 0 {
                                                kommit.date = calendar.date(byAdding: .month, value: Int(frequency.duration), to: kommit.date!)
                                            } else if let date = kommit.date, frequency.component == 1 {
                                                if let weekday = calendar.dateComponents([.weekday], from: date).weekday {
                                                    let selectedDays = Days(rawValue: frequency.daysOfTheWeek)
                                                    if selectedDays.count() == 1 {kommit.date = calendar.date(byAdding: .day, value: Int(frequency.duration * 7), to: kommit.date!)
                                                    } else {
                                                        let currentDay = Days(rawValue: Int16(weekday - 1))
                                                        var futureDay = currentDay
                                                        var foundDay = false
                                                        repeat {
                                                            if futureDay == Days.saturday{
                                                                futureDay = Days.sunday
                                                            } else {
                                                                futureDay = Days(rawValue: futureDay.rawValue << 1)
                                                            }
                                                            if selectedDays.contains(futureDay) || futureDay == currentDay {
                                                                let components = DateComponents.init(calendar: calendar, weekday: futureDay.calendarValue())
                                                                kommit.date = calendar.nextDate(after: date, matching: components, matchingPolicy: .nextTimePreservingSmallerComponents)
                                                                foundDay = true
                                                            }
                                                        } while !foundDay
                                                    }
                                                }
                                            } else if frequency.component == 2 {
                                                kommit.date = calendar.date(byAdding: .day, value: Int(frequency.duration), to: kommit.date!)
                                            }
                                        }
                                    }
                                    self.persistentContainer.saveContext(context)
                                }
                            }
                        }
                    }
                }
                task.resume()
            }
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
}
