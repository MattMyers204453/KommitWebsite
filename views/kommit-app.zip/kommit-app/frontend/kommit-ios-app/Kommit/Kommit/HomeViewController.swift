//
//  HomeViewController.swift
//  Kommit
//
//  Created by Jordan Hendley on 11/22/21.
//

import Foundation
import UIKit
import CoreData

/**
 Home is where the heart is. This view controller displays all existing kommits,
 organizing them based on how much time is left
 */
class HomeViewController: UIViewController, HasPersistentContainer{
    var container: NSPersistentContainer!
    @IBOutlet var tableView: UITableView!
    var todayKommits = [Kommit]()
    var tomorrowKommits = [Kommit]()
    var weekKommits = [Kommit]()
    var eventuallyKommits = [Kommit]()
    var completedKommits = [Kommit]()
    var allKommits = [Kommit]()
    var selectedKommit: Kommit?
    
    /**
     Makes sure any views being presented have the appropriate information
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if var destination = segue.destination as? HasPersistentContainer{
            destination.container = container
        }
        if let index = self.tableView.indexPathForSelectedRow, let destination = segue.destination as? EditKommitViewController{
            destination.kommit = getKommitfor(indexPath: index)
        }
        if let destination = segue.destination as? HistoryViewController {
            destination.kommit = selectedKommit
        }
    }
    
    /**
     Download current information from the server
     */
    override func viewDidLoad() {
        let button = UIBarButtonItem.init(title: "Cancel", style: .plain, target: nil, action: nil)
        if let font = UIFont(name: "Didot", size: 17) {
            button.setTitleTextAttributes([.font:font], for: .normal)
        }
        navigationItem.backBarButtonItem = button
        reloadData()
        downloadKommits()
        downloadOrganizations()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        reloadData()
    }
    
    /**
     Changes the table to allow deleting of kommits
     */
    @IBAction func didPressTrash(sender: UIBarButtonItem){
        tableView.setEditing(!tableView.isEditing, animated: true)
        if tableView.isEditing {
            self.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(didPressTrash(sender:)))
        } else {
            self.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .trash, target: self, action: #selector(didPressTrash(sender:)))
        }
    }
    
    /**
     Downloads all the Kommits for the user.
     Saves the new kommits, and deletes kommits not in the download
     */
    func downloadKommits() {
        if let url = URL(string: Constants.host + "kommit"){
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.setValue(UserDefaults.standard.string(forKey: Defaults.authToken) ?? "", forHTTPHeaderField: "Token")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
                if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 || httpResponse.statusCode == 204{
                    if let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [[String:Any]] {
                        var newKommits = [[String:Any]]()
                        var kommitsToDelete = [Kommit]()
                        let context = container.newBackgroundContext()
                        //Finds kommits not in the download to delete
                        for kommit in allKommits {
                            if !json.contains(where: { element in
                                if let idString = element["kommit_id"] as? String, let kommitId = UUID(uuidString: idString){
                                    return kommitId == kommit.kommitId
                                }
                                return false
                            }) {
                                kommitsToDelete.append(kommit)
                            }
                        }
                        //Finds new kommits to save
                        for element in json{
                            if let idString = element["kommit_id"] as? String, let kommitId = UUID(uuidString: idString){
                                if !(allKommits.contains(where: { kommit in
                                    return kommit.kommitId == kommitId
                                })){
                                    newKommits.append(element)
                                }
                            }
                        }
                        context.performAndWait {
                            for newKommit in newKommits {
                                let kommit = Kommit(context: context)
                                if let idString = newKommit["kommit_id"] as? String, let kommitId = UUID(uuidString: idString){ kommit.kommitId = kommitId}
                                if let userIdString = newKommit["user_id"] as? String, let userId = UUID(uuidString: userIdString){ kommit.userId = userId}
                                if let bet = newKommit["bet"] as? Double {
                                    kommit.bet = NSDecimalNumber(string: String(bet))
                                }
                                if let label = newKommit["name"] as? String{ kommit.label = label}
                                if let date = newKommit["date"] as? String {
                                    let iso = ISO8601DateFormatter()
                                    iso.timeZone = .current
                                    kommit.date = iso.date(from: date)
                                }
                                
                                let location = Location(context: context)
                                if let name = newKommit["location_name"] as? String { location.name = name}
                                if let longitude = newKommit["longitude"] as? Double { location.longitude = longitude}
                                if let latitude = newKommit["latitude"] as? Double { location.latitude = latitude}
                                kommit.location = location
                                
                                let frequency = Frequency(context: context)
                                if let component = newKommit["component"] as? Int16 { frequency.component = component}
                                if let days = newKommit["days_of_the_week"] as? Int16 { frequency.daysOfTheWeek = days}
                                if let duration = newKommit["duration"] as? Int32 { frequency.duration = duration}
                                kommit.frequency = frequency
                                
                                if let orgIdString = newKommit["organization_id"] as? String, let orgId = UUID(uuidString: orgIdString){
                                    let request = Organization.fetchRequest()
                                    let predicate = NSPredicate(format: "organizationId = %@", orgId as CVarArg)
                                    request.predicate = predicate
                                    if let fetchedOrganizations = try? context.fetch(request), fetchedOrganizations.count > 0{
                                        kommit.organization = fetchedOrganizations.first
                                    } else {
                                        let organization = Organization.init(context: context)
                                        organization.organizationId = orgId
                                        kommit.organization = organization
                                    }
                                }
                            }
                            
                            for kommit in kommitsToDelete {
                                let deletingKommit = context.object(with: kommit.objectID)
                                context.delete(deletingKommit)
                            }
                            container.saveContext(context)
                        }
                    }
                }
                DispatchQueue.main.async {
                    self.reloadData()
                }
            }
            task.resume()
        }
    }
    
    /**
     Downloads the existing organizations
     */
    func downloadOrganizations(){
        if let url = URL(string: Constants.host + "organization"){
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.setValue(UserDefaults.standard.string(forKey: Defaults.authToken) ?? "", forHTTPHeaderField: "Token")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
                if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 || httpResponse.statusCode == 204{
                    if let data = data, let organizations = try? JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [[String:Any]] {
                        
                        let context = container.newBackgroundContext()
                        let fetchedOrgs = try? context.fetch(Organization.fetchRequest())
                        
                        for organization in organizations {
                            if let idString = organization["organization_id"] as? String, let orgId = UUID(uuidString: idString){
                                let org: Organization
                                if let fetchedOrg = fetchedOrgs?.first(where: { org in
                                    return org.organizationId == orgId
                                }) {
                                    org = fetchedOrg
                                } else {
                                    org = Organization(context: context)
                                    org.organizationId = orgId
                                }
                                if let label = organization["label"] as? String{
                                    org.name = label
                                }
                                if let email = organization["paypal_email"] as? String{
                                    org.email = email
                                }
                            }
                        }
                        
                        container.saveContext(context)
                    }
                }
            }
            task.resume()
        }
    }
    
    /**
     Organizes the kommits into different arrays based on how far away the due date is
     */
    func reloadData() {
        container.viewContext.performAndWait {
            let request = Kommit.fetchRequest()
            let sort = NSSortDescriptor(key: "date", ascending: true)
            request.sortDescriptors = [sort]
            if let fetchedKommits = try? container.viewContext.fetch(request){
                allKommits.removeAll()
                for kommit in fetchedKommits {
                    if !allKommits.contains(kommit){
                        allKommits.append(kommit)
                    }
                    if let date = kommit.date {
                        let calendar = Calendar.current
                        let today = Date()
                        var components = DateComponents()
                        components.day = 8
                        components.second = -1
                        let weekDate = calendar.date(byAdding: components, to: today)!
                        if date > today && calendar.isDateInToday(date) {
                            if !todayKommits.contains(kommit){
                                todayKommits.append(kommit)
                            }
                        } else if calendar.isDateInTomorrow(date){
                            if !tomorrowKommits.contains(kommit){
                                tomorrowKommits.append(kommit)
                            }
                        } else if date > today && date < weekDate {
                            if !weekKommits.contains(kommit){
                                weekKommits.append(kommit)
                            }
                        } else if date < today {
                            if !completedKommits.contains(kommit){
                                completedKommits.append(kommit)
                            }
                        } else {
                            if !eventuallyKommits.contains(kommit){
                                eventuallyKommits.append(kommit)
                            }
                        }
                    }
                }
            }
        }
        tableView.reloadData()
    }
    
    /**
     Helper function to get a kommit out of the correct array
     */
    func getKommitfor(indexPath: IndexPath) -> Kommit{
        if indexPath.section == 0 {
            return todayKommits[indexPath.row]
        } else if indexPath.section == 1 {
            return tomorrowKommits[indexPath.row]
        } else if indexPath.section == 2 {
            return weekKommits[indexPath.row]
        } else if indexPath.section == 3 {
            return eventuallyKommits[indexPath.row]
        } else {
            return completedKommits[indexPath.row]
        }
    }
}

/**
 Methods to organize and display the table of kommits
 */
extension HomeViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return todayKommits.count
        } else if section == 1 {
            return tomorrowKommits.count
        }else if section == 2 {
            return weekKommits.count
        }else if section == 3 {
            return eventuallyKommits.count
        }else if section == 4 {
            return completedKommits.count
        }
        return 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 {
            return todayKommits.count > 0 ? "Today" : nil
        } else if section == 1 {
            return tomorrowKommits.count > 0 ? "Tomorrow" : nil
        } else if section == 2 {
            return weekKommits.count > 0 ? "This Week" : nil
        } else if section == 3 {
            return eventuallyKommits.count > 0 ? "Eventually" : nil
        } else if section == 4 {
            return completedKommits.count > 0 ? "Completed" : nil
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomeCell", for: indexPath) as! HomeCell
        let kommit = getKommitfor(indexPath: indexPath)
        cell.home = self
        cell.kommit = kommit
        cell.nameLabel.text = kommit.label
        if let bet = kommit.bet?.decimalValue{
            cell.amountLabel.text = bet.formatted(.number.precision(.fractionLength(2)))
        } else {
            cell.amountLabel.text = "$_.__"
        }
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd, h:mm"
        let dateString: String
        if let date = kommit.date {
            dateString = formatter.string(from: date)
        } else {
            dateString = "No Date"
        }
        cell.dateLabel.text = dateString
        if let count = kommit.histories?.count, count > 0 {
            cell.historyButton.isHidden = false
        } else {
            cell.historyButton.isHidden = true
        }
        
        if indexPath.section == 0 {
            cell.backgroundColor = UIColor.orange.withAlphaComponent(0.1)
        } else if indexPath.section == 1 {
            cell.backgroundColor = UIColor.yellow.withAlphaComponent(0.1)
        } else if indexPath.section == 2 {
            cell.backgroundColor = UIColor.blue.withAlphaComponent(0.1)
        } else if indexPath.section == 3 {
            cell.backgroundColor = UIColor.purple.withAlphaComponent(0.1)
        } else {
            cell.backgroundColor = UIColor.clear
        }
        return cell;
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        let kommit = getKommitfor(indexPath: indexPath)
        if kommit.successes < 3 {
            let alert = UIAlertController(title: "Are you sure?", message: "This Kommit has not been completed enough times, you will LOSE YOUR MONEY!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Yes", style: .destructive, handler: { [self] action in
                delete(kommit: kommit, indexPath: indexPath)
            }))
            alert.addAction(UIAlertAction(title: "No", style: .cancel))
            present(alert, animated: true)
        } else {
            delete(kommit: kommit, indexPath: indexPath)
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        guard let header = view as? UITableViewHeaderFooterView else { return }
        header.textLabel?.font = UIFont(name: "Didot", size: 17)
        header.textLabel?.sizeToFit()
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if indexPath.section == 4 {
            return false
        }
        return true
    }
    
    func delete(kommit: Kommit, indexPath: IndexPath){
        if let id = kommit.kommitId?.uuidString, let url = URL(string: Constants.host + "kommit/\(id)"){
            var request = URLRequest(url: url)
            request.httpMethod = "DELETE"
            request.setValue(UserDefaults.standard.string(forKey: Defaults.authToken)!, forHTTPHeaderField: "Token")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
                if let response = response as? HTTPURLResponse {
                    print("status: %@", response.statusCode)
                    if response.statusCode == 200 {
                        DispatchQueue.main.async { [self] in
                            container.viewContext.refreshAllObjects()
                            container.viewContext.delete(kommit)
                            container.saveViewContext()
                            if indexPath.section == 0 {
                                todayKommits.remove(at: indexPath.row)
                            } else if indexPath.section == 1 {
                                tomorrowKommits.remove(at: indexPath.row)
                            }else if indexPath.section == 2 {
                                weekKommits.remove(at: indexPath.row)
                            }else if indexPath.section == 3 {
                                eventuallyKommits.remove(at: indexPath.row)
                            }
                            allKommits.removeAll { allKommit in
                                return kommit == allKommit
                            }
                            tableView.deleteRows(at: [indexPath], with: .fade)
                        }
                    }
                }
            }
            task.resume()
        }
    }
}
