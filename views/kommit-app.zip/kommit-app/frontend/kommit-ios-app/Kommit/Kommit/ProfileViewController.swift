//
//  ProfileViewController.swift
//  Kommit
//
//  Created by Jordan Hendley on 1/29/22.
//

import Foundation
import UIKit
import BraintreeDropIn

/**
 A view to display all profile information
 Currently it only has the payment information
 */
class ProfileViewController: UIViewController{
    
    @IBOutlet weak var paymentBtn: UIButton!
    @IBOutlet weak var iconView: UIStackView!
    
    override func viewDidLoad() {
        if let payment = UserDefaults.standard.string(forKey: Defaults.paymentMethod) {
            paymentBtn.setTitle(payment, for: .normal)
        }
    }
    
    /**
     When the payment button is pressed and the Braintree api does it's thing,
     we grab the information and send it up to the Paypal server if it exists
     */
    @IBAction func didPressPaymentBtn(_ sender: Any) {
        let request =  BTDropInRequest()
            let dropIn = BTDropInController(authorization: Constants.paymentTokenizationKeySandbox, request: request)
            { (controller, result, error) in
                if (error != nil) {
                    print("ERROR")
                } else if (result?.isCanceled == true) {
                    print("CANCELED")
                } else if let result = result {
                    print(result)
                    if let nonce = result.paymentMethod?.nonce {
                        self.postNonceToServer(paymentMethodNonce: nonce)
                    }
                    self.paymentBtn.setTitle(result.paymentDescription, for: .normal)
                    UserDefaults.standard.set(result.paymentDescription, forKey: Defaults.paymentMethod)
                }
                controller.dismiss(animated: true, completion: nil)
            }
            self.present(dropIn!, animated: true, completion: nil)
    }
    
    /**
     The information from the Braintree api exists, so send it up
     */
    func postNonceToServer(paymentMethodNonce: String){
        let paymentURL = URL(string: "\(Constants.paypalHost)checkout")!
        var request = URLRequest(url: paymentURL)
        
        request.httpBody = "paymentMethodNonce=\(paymentMethodNonce)".data(using: String.Encoding.utf8)
        request.setValue(UserDefaults.standard.string(forKey: Defaults.authToken)!, forHTTPHeaderField: "Token")
        request.httpMethod = "POST"

        URLSession.shared.dataTask(with: request) { (data, response, error) -> Void in
            print("HERE")
        }.resume()
    }
}


