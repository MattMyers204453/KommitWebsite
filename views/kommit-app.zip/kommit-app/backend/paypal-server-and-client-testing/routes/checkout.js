const express = require('express');
const router = express.Router();
//const braintree = require('braintree');
const axios = require('axios');


//AUTHORIZE TRANSACTION BUT DO NOT TRIGGER IT
router.post('/', (req, res, next) => {

  //var userID = req.body.userID;
  var Token = req.header('Token')
  //console.log("Received UserID: " + userID);

  var encodedToken = "em1wc2p2ancyODY2a3l3NzpmN2MyNDNjMTQ4MTg1MDA0MWQyMDYwZTdkY2RiYTEwZA==";//buf.toString('base64');
  const nonceFromTheClient = req.body.paymentMethodNonce;
  axios({
    method: 'post',
    url: 'https://payments.sandbox.braintree-api.com/graphql',
    headers: {
      'Authorization': encodedToken,
      'Braintree-Version': '2019-01-01',
      'Content-Type': 'application/json'
    },
    data: {
      query: `mutation vaultPaymentMethod($input: VaultPaymentMethodInput!) {
          vaultPaymentMethod(input: $input) {
            paymentMethod {
              id
            }
            verification {
              status
            }
          }
        }` ,
      variables: {
        "input": {
          "paymentMethodId": nonceFromTheClient,//"fake-valid-nonce"
        }
      }
    }
  }).then(function (response) {
    console.log("----YOU HAVE AUTHORIZED AND SAVED PAYMENT INFORMATION (although successful authorization is not guranteed)----");
    console.log(response.data.data.vaultPaymentMethod.paymentMethod.id);
    var paymentMethodid = response.data.data.vaultPaymentMethod.paymentMethod.id;
    console.log("Payment Method ID: " + paymentMethodid);
    console.log("Nonce: " + nonceFromTheClient);
    module.exports.paymentMethodID = paymentMethodid;
    res.send("This is the /checkout server response");

    //HERE, hit the Go server and give it the userID as well as the newly acquired paymentMethodid
    //console.log("userID: " + userID);
    var gatewayUrl = process.env.GATEWAY_ADDRESS || "http://54.237.48.195:8080"
    console.log("Token: " + Token)
    console.log("paymentid: " + paymentMethodid);
    axios({
      method: 'post',
      url: gatewayUrl + "/UpdatePaypal",//'http://localhost:8080/UpdatePaypal', 
      headers: {
        'Content-Type': 'application/json',
        'Token': Token
      },
      data: {
        //user_id: userID,
        PayPalMethodID: paymentMethodid
      }
    }).then(function (response) {
      //console.log(response);
    });
    

  });

  /*
  var encodedToken = "em1wc2p2ancyODY2a3l3NzpmN2MyNDNjMTQ4MTg1MDA0MWQyMDYwZTdkY2RiYTEwZA==";//buf.toString('base64');
  const nonceFromTheClient = req.body.paymentMethodNonce;
  axios({
    method: 'post',
    url: 'https://payments.sandbox.braintree-api.com/graphql',
    headers: {
      'Authorization': encodedToken,
      'Braintree-Version': '2019-01-01',
      'Content-Type': 'application/json'
    },
    data: {
      query: `mutation authorizePaymentMethod($input: AuthorizePaymentMethodInput!) {
          authorizePaymentMethod(input: $input) {
            transaction {
              id
              status
            }
          }
        }` ,
      variables: {
        "input": {
          "paymentMethodId": nonceFromTheClient,//"fake-valid-nonce"
          "transaction": {
            "amount": "10000"
          }
        }
      }
    }
  }).then(function (response) {
    console.log("----YOU HAVE AUTHORIZED AND SAVED PAYMENT INFORMATION (although successful authorization is not guranteed)----");
    var transactionid = response.data.data.authorizePaymentMethod.transaction.id;
    console.log("Transaction ID: " + transactionid);
    console.log("Nonce: " + nonceFromTheClient);
    console.log("Amount: " + "10,000");//.authorizePaymentMethod);
    module.exports.transactionID = transactionid;
    res.send("This is the /checkout server repsonse");
  });
  */

});

module.exports = router;