const express = require('express');
const router = express.Router();
const braintree = require('braintree');
const axios = require('axios');

const checkoutModule = require('./checkout');

//var nonce = checkoutModule.nonce;
function between(min, max) {  
    return Math.floor(
      Math.random() * (max - min) + min
    )
  }

// TRIGGER AUTHORIZED PAYMENT
router.post('/', (req, res, next) => {
    //const nonceFromTheClient = req.body.paymentMethodNonce;
    //var decodedToken = gateway.publicKey + ":" + gateway.privateKey;
    //const buf = Buffer.from(decodedToken, 'utf8');

    var randomOrderID = '' + between(1, 10000);

    var bet = req.body.bet;

    // USE THIS TO TRIGGER PAYMENT ONCE CONNECTED TO GO SERVER!!!!!!
    var paymentmethodid = req.body.userPaymentMethodID; 

    var encodedToken = "em1wc2p2ancyODY2a3l3NzpmN2MyNDNjMTQ4MTg1MDA0MWQyMDYwZTdkY2RiYTEwZA==";//buf.toString('base64');

    axios({
        method: 'post',
        url: 'https://payments.sandbox.braintree-api.com/graphql',
        headers: {
            'Authorization': encodedToken,
            'Braintree-Version': '2019-01-01',
            'Content-Type': 'application/json'
        },
        data: {
            query: `mutation chargePaymentMethod($input: ChargePaymentMethodInput!) {
            chargePaymentMethod(input: $input) {
              transaction {
                id
              }
            }
          }` ,
            variables: {
                "input": {
                    "paymentMethodId": paymentmethodid, //checkoutModule.userPaymentMethodID, // USE THIS TO TRIGGER PAYMENT ONCE CONNECTED TO GO SERVER!!!!!!
                    "transaction": {
                        "amount": bet,
                        "orderId": randomOrderID //THIS HACKY SOLUTION CREATES A LOW CHANCE OF GETTING A "GATEWAY REJECTED: DUPLICATE" ERROR
                      }
                }
            }
        }
    }).then(function (response) {
        console.log("----YOU HAVE TRIGGERED A TRANSACTION (although a successful transaction is not guranteed, either)----");
        console.log("TRANSACTION AMOUNT: " + bet);
        console.log(response.data);
        res.send("This is the /capture server repsonse");

        //REMOVE PAYMENT FROM VAULT. FOR TESTING ONLY!!!!!
        /*
        axios({
            method: 'post',
            url: 'https://payments.sandbox.braintree-api.com/graphql',
            headers: {
                'Authorization': encodedToken,
                'Braintree-Version': '2019-01-01',
                'Content-Type': 'application/json'
            },
            data: {
                query: `mutation deletePaymentMethodFromVault($input: DeletePaymentMethodFromVaultInput!) {
                deletePaymentMethodFromVault(input: $input) {
                    clientMutationId 
                }
              }` ,
                variables: {
                    "input": {
                        "paymentMethodId": paymentmethodid //checkoutModule.paymentMethodID //"fake-valid-nonce"
                    }
                }
            }
        }).then(function (response) {
            console.log("PAYMENT METHOD SHOULD BE REMOVED FROM VAULT.");
            console.log(response.data)
        });
        */
        
    });

    /*
    var bet = req.body.bet;


    var encodedToken = "em1wc2p2ancyODY2a3l3NzpmN2MyNDNjMTQ4MTg1MDA0MWQyMDYwZTdkY2RiYTEwZA==";//buf.toString('base64');

    axios({
        method: 'post',
        url: 'https://payments.sandbox.braintree-api.com/graphql',
        headers: {
            'Authorization': encodedToken,
            'Braintree-Version': '2019-01-01',
            'Content-Type': 'application/json'
        },
        data: {
            query: `mutation captureTransaction($input: CaptureTransactionInput!) {
            captureTransaction(input: $input) {
              transaction {
                id
              }
            }
          }` ,
            variables: {
                "input": {
                    "transactionId": checkoutModule.transactionID, //"fake-valid-nonce"
                    "amount": bet
                }
            }
        }
    }).then(function (response) {
        console.log("----YOU HAVE TRIGGERED A TRANSACTION (although a successful transaction is not guranteed, either)----");
        console.log("TRANSACTION AMOUNT: " + bet);
        console.log(response.data);
        res.send("This is the /capture server repsonse");
    });
    */
});

module.exports = router;