const express = require('express');
const router = express.Router();
const axios = require('axios');
var apn = require('apn');


router.post('/', (req, res, next) => {

  var kid = req.body.kid;

  var deviceToken = req.body.deviceToken; //"7a6f14f0153adfaa5e855d6f2aa114e2f47180fb22087c1b223c213bc6f981a0"

  
  var options = {
    token: {
      key: "\AuthKey_P9KVGF4XQ2.p8",
      keyId: "P9KVGF4XQ2",
      teamId: "4J9C66F42C"
    },
    production: false
  };

  var apnProvider = new apn.Provider(options);


  var note = new apn.Notification();

  //note.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
  note.pushType = "alert";
  note.priority = 10;
  //note.badge = 0;
  //note.sound = "ping.aiff";
  note.alert = "Checking Location..."//"\uD83D\uDCE7 \u2709 BACKGROUND KOMMIT TEST NOTIF";
  note.payload = { 'KID': kid }; //{ 'messageFrom': 'Matt Myers' };
  note.topic = "Kommit.Kommit";

  apnProvider.send(note, deviceToken).then( (result) => {
    console.log(result);
    res.send(result);
  });

});

module.exports = router;