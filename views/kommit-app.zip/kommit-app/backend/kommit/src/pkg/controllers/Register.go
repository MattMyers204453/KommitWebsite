package controllers

import (
	"fmt"
	"kommit/src/pkg/models"
	"kommit/src/pkg/utils"
	"net/http"
	"strings"

	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
)

func (c Controller) Register(w http.ResponseWriter, r *http.Request) {

	user := &models.User{}
	utils.ParseBody(r, user)
	fmt.Println(user)

	user.UserID = uuid.NewString()
	user.Username = strings.ToLower(user.Username)
	user.Role = 0

	hashedpw, err := bcrypt.GenerateFromPassword([]byte(user.Password), bcrypt.MinCost)
	if err != nil {
		panic(err)
	}
	user.Password = string(hashedpw)
	if err != nil {
		panic(err)
	}

	_, err = c.s.Register(user)
	if err != nil {
		panic(err)
	}

	w.WriteHeader(http.StatusOK)
	w.Write([]byte(`{"status": successfully created"}`))
}
