package controllers

import (
	"kommit/src/pkg/models"
	"net/http"
)

type Controller struct {
	a models.AuthorizedTokens
	s models.Store
}

func NewController() *Controller {
	cont := Controller{
		a: models.AuthorizedTokens{make(map[string]string)},
		s: models.NewStore(),
	}
	cont.a.Seed()
	return &cont
}

func (c Controller) GetUserFromToken(r *http.Request) string {
	token := r.Header.Get("Token")
	if token == "" {
		panic("no token")
	}
	userID, err := c.a.GetID(token)
	if err != nil {
		panic(err)
	}
	return userID
}
