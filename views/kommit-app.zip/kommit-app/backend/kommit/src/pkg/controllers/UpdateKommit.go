package controllers

import (
	"net/http"
)

func (c Controller) UpdateKommit(w http.ResponseWriter, r *http.Request) {

}
