package controllers

import (
	"encoding/json"
	"fmt"
	"kommit/src/pkg/utils"

	"net/http"
)

type LoginInfo struct {
	Username    string `json:"username"`
	Password    string `json:"password"`
	DeviceToken string `json:"devicetoken"`
}
type LoginResponse struct {
	Token string `json:"token"`
}

func (c Controller) Login(w http.ResponseWriter, r *http.Request) {

	user := &LoginInfo{}
	utils.ParseBody(r, user)
	fmt.Println(user.Username)

	userID, err := c.s.Login(user.Username, user.Password, user.DeviceToken)
	//need to figure out how/where to handle this errors
	if err != nil {
		panic(err)
	}
	loginResponse := LoginResponse{c.a.GenerateToken(userID)}
	res, _ := json.Marshal(loginResponse)
	w.Header().Set("Content-Type", "pkglocation/json")
	w.WriteHeader(http.StatusOK)

	w.Write(res)

}
