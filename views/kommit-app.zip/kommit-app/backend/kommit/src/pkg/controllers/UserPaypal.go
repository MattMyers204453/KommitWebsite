package controllers

import (
	"fmt"
	"kommit/src/pkg/models"
	"kommit/src/pkg/utils"
	"net/http"
)

func (c Controller) UserPaypal(w http.ResponseWriter, r *http.Request) {
	fmt.Println("User Paypal Endpoint")
	userID := c.GetUserFromToken(r)
	paypal := &models.PaypalInfo{}
	utils.ParseBody(r, paypal)
	fmt.Println(paypal)
	paypal.UserID = userID

	err := c.s.UpdatePaypal(paypal)

	if err != nil {
		panic(err)
	}

	w.WriteHeader(http.StatusOK)

}
