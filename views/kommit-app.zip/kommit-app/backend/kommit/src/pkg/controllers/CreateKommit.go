package controllers

import (
	"encoding/json"
	"kommit/src/pkg/models"
	"kommit/src/pkg/utils"
	"net/http"

	"github.com/google/uuid"
)

func (c Controller) CreateKommit(w http.ResponseWriter, r *http.Request) {
	userID := c.GetUserFromToken(r)
	//userID := "42b56c98-8154-11ec-a92c-d85ed30193f8"
	kommit := &models.Kommit{}
	utils.ParseBody(r, kommit)
	kommit.UserID = userID
	kommit.KommitID = uuid.NewString()
	//fmt.Println(kommit)
	addedKommit, err := c.s.CreateKommit(kommit)
	if err != nil {
		panic(err)
	}

	res, err := json.Marshal(addedKommit)
	if err != nil {
		panic(err)
	}

	w.WriteHeader(http.StatusOK)
	w.Write(res)

}
