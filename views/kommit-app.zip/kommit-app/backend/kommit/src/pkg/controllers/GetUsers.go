package controllers

import (
	"encoding/json"
	"net/http"
)

func (c Controller) GetUsers(w http.ResponseWriter, r *http.Request) {
	newUser := c.s.GetAllUsers()
	res, _ := json.Marshal(newUser)
	w.Header().Set("Content-Type", "pkglocation/json")
	w.WriteHeader(http.StatusOK)

	w.Write(res)
}
