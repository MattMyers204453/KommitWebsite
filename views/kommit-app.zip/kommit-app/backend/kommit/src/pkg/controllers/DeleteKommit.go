package controllers

import (
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"
)

func (c Controller) DeleteKommit(w http.ResponseWriter, r *http.Request) {
	userID := c.GetUserFromToken(r)
	vars := mux.Vars(r)
	kommitID := vars["KommitID"]

	k, err := c.s.GetKommitbyID(userID, kommitID)

	if err != nil {
		panic(err)
	}

	if k.NumberOfSuccess < 3 {
		c.s.Capture(kommitID)
	}

	kommit := c.s.DeleteKommit(userID, kommitID)

	res, _ := json.Marshal(kommit)

	w.Header().Set("Content-Type", "pkglocation/json")
	w.WriteHeader(http.StatusOK)

	w.Write(res)

}
