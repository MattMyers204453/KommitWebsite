package controllers

import (
	"encoding/json"
	"fmt"
	"kommit/src/pkg/models"
	"kommit/src/pkg/utils"
	"net/http"

	//"time"

	"github.com/gorilla/mux"
)

type CheckInRes struct {
	Status string `json:"status"`
}

func (c Controller) CheckIn(w http.ResponseWriter, r *http.Request) {
	userID := c.GetUserFromToken(r)
	fmt.Println("----" + userID)
	kID := mux.Vars(r)["KommitID"]
	kommit, _ := c.s.GetKommitbyID(userID, kID)

	//kommitDate := kommit.Date
	kommitLong := kommit.Longitude
	kommitLat := kommit.Latitude

	loc := &models.Location{}
	utils.ParseBody(r, loc)
	loc.UserID = userID
	err := c.s.CreateUserLocation(loc)
	if err != nil {
		panic(err)
	}
	//kTime, err := time.Parse("2022-01-31T12:30:00-07:00", kommitDate)
	//kTime, err2 := time.Parse(time.RFC3339, kommitDate) //Fixed?
	//if err2 != nil {
	//panic(err2)
	//}
	//timePassed := c.s.CheckTime(loc.Date, kTime) //FIXME: time not parsing correctly
	within := c.s.CheckLocation(kommitLat, kommitLong, loc.Latitude, loc.Longitude)
	//timePassed = true
	status := "undecided"

	if within {
		status = "complete"
		err = c.s.UpdateSucess(kID)
		if err != nil {
			panic(err)
		}

	} else if !within {
		status = "failed"
	}

	res, err := json.Marshal(CheckInRes{status})
	if err != nil {
		panic(err)
	}

	w.WriteHeader(http.StatusOK)
	w.Write(res)
}
