package controllers

import "net/http"

func (c Controller) CreateFrequency(w http.ResponseWriter, r *http.Request) {

}
