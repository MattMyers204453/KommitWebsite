package controllers

import (
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"
)

//change this to find by name later
func (c Controller) GetKommitbyID(w http.ResponseWriter, r *http.Request) {
	userID := c.GetUserFromToken(r)
	kID := mux.Vars(r)["KommitID"]
	kommit, err := c.s.GetKommitbyID(userID, kID)
	if err != nil {
		panic(err)
	}
	res, _ := json.Marshal(kommit)

	w.Header().Set("Content-Type", "pkglocation/json")
	w.WriteHeader(http.StatusOK)

	w.Write(res)
}
