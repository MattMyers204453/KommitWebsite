package controllers

import (
	"encoding/json"
	"net/http"
)

func (c Controller) GetOrganizations(w http.ResponseWriter, r *http.Request) {
	c.GetUserFromToken(r)
	orgs, err := c.s.GetOrganizations()
	if err != nil {
		panic(err)
	}
	res, _ := json.Marshal(orgs)
	w.Header().Set("Content-Type", "pkglocation/json")
	w.WriteHeader(http.StatusOK)

	w.Write(res)
}
