package controllers

import (
	"kommit/src/pkg/utils"
	"net/http"
)

type request struct {
	Kommit_id string `json:"kommit_id"`
}

func (c Controller) Capture(w http.ResponseWriter, r *http.Request) {

	request_instance := &request{}

	utils.ParseBody(r, request_instance)

	c.s.Capture(request_instance.Kommit_id)

	w.WriteHeader(http.StatusOK)

}
