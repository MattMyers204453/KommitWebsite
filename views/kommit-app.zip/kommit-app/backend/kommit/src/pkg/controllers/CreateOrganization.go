package controllers

import (
	"encoding/json"
	"kommit/src/pkg/models"
	"kommit/src/pkg/utils"
	"net/http"

	"github.com/google/uuid"
)

func (c Controller) CreateOrganization(w http.ResponseWriter, r *http.Request) {
	c.GetUserFromToken(r) //TODO: seperate private orgs
	org := &models.Organization{}
	utils.ParseBody(r, org)
	org.OrganizationID = uuid.NewString()
	addedOrg, err := c.s.CreateOrganization(org)
	if err != nil {
		panic(err)
	}

	res, err := json.Marshal(addedOrg)
	if err != nil {
		panic(err)
	}

	w.WriteHeader(http.StatusOK)
	w.Write(res)
}
