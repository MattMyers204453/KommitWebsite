package controllers

import (
	"encoding/json"
	"net/http"
)

func (c Controller) GetKommits(w http.ResponseWriter, r *http.Request) {
	userID := c.GetUserFromToken(r)
	kommits := c.s.GetKommits(userID)
	res, _ := json.Marshal(kommits)
	w.Header().Set("Content-Type", "pkglocation/json")
	w.WriteHeader(http.StatusOK)

	w.Write(res)
}
