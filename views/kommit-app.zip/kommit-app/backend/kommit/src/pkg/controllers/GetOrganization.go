package controllers

import (
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"
)

func (c Controller) GetOrganization(w http.ResponseWriter, r *http.Request) {
	c.GetUserFromToken(r)
	orgID := mux.Vars(r)["OrganizationID"]
	org, err := c.s.GetOrganization(orgID)
	if err != nil {
		panic(err)
	}
	res, _ := json.Marshal(org)
	w.Header().Set("Content-Type", "pkglocation/json")
	w.WriteHeader(http.StatusOK)

	w.Write(res)
}
