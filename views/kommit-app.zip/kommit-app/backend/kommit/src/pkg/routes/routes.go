package routes

import (
	"fmt"
	"kommit/src/pkg/controllers"
	"net/http"
	"runtime"

	"github.com/gorilla/mux"
)

func RegisterRoutes(router *mux.Router, c *controllers.Controller) {
	//Healthcheck
	router.HandleFunc("/", c.Health).Methods("GET")
	//Kommit Routes
	router.HandleFunc("/kommit", c.CreateKommit).Methods("POST")
	router.HandleFunc("/kommit/{KommitID}", c.GetKommitbyID).Methods("GET")
	router.HandleFunc("/kommit", c.GetKommits).Methods("GET")
	router.HandleFunc("/kommit/{KommitID}", c.UpdateKommit).Methods("PUT")    //TODO:
	router.HandleFunc("/kommit/{KommitID}", c.DeleteKommit).Methods("DELETE") //TODO:
	router.HandleFunc("/kommit/{KommitID}/check-in", c.CheckIn).Methods("POST")

	//Org Routes
	router.HandleFunc("/organization", c.GetOrganizations).Methods("GET")
	router.HandleFunc("/organization", c.CreateOrganization).Methods("POST")
	router.HandleFunc("/organization/{OrganizationID}", c.GetOrganization).Methods("GET")

	//Freq routes

	//User Routes
	router.HandleFunc("/users", c.GetUsers).Methods("GET")

	//Paypal routes
	router.HandleFunc("/capture", c.Capture).Methods("POST")

	//middlware
	router.Use(panicRecovery)

	//registration and authentication
	router.HandleFunc("/register", c.Register).Methods("POST")
	router.HandleFunc("/login", c.Login).Methods("POST")

	//paypal

	router.HandleFunc("/UpdatePaypal", c.UserPaypal).Methods("POST")

}

// https://www.jajaldoang.com/post/handle-panic-in-http-server-using-middleware-go/
func panicRecovery(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if err := recover(); err != nil {
				buf := make([]byte, 2048)
				n := runtime.Stack(buf, false)
				buf = buf[:n]

				fmt.Printf("recovering from err %v\n %s", err, buf)
				w.Write([]byte(fmt.Sprintf(`{"error":"%v"}`, err)))
			}
		}()

		h.ServeHTTP(w, r)
	})
}
