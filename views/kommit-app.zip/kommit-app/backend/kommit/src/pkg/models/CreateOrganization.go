package models

import "fmt"

func (s Store) CreateOrganization(o *Organization) (*Organization, error) {
	fmt.Println(o)
	err := s.db.Create(&o).Error
	if err != nil {
		return nil, err
	}

	return o, nil
}
