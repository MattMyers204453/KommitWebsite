package models

import (
	"context"
	"fmt"
	"time"

	"github.com/procyon-projects/chrono"
)

func (s Store) CreateKommit(k *Kommit) (*Kommit, error) {
	_, err := s.GetOrganization(k.OrganizationID)
	if err != nil {
		return nil, err
	}
	err = s.db.Create(&k).Error
	if err != nil {
		return nil, err
	}

	fmt.Println("---- SCHEDULER IS SETTING A TIMER FOR THIS KOMMIT")
	startKommitScheduler(k.KommitID, k.Date, s)
	fmt.Println("---- SCHEDULER SUCCESSFULLY SET A TIMER FOR THIS KOMMIT")

	fmt.Println(k)

	return k, nil
}

func startKommitScheduler(kommitID string, kommitDate string, s Store) {
	kDate, err2 := time.Parse(time.RFC3339, kommitDate)
	if err2 != nil {
		panic(err2)
	}

	taskScheduler := chrono.NewDefaultTaskScheduler()

	taskScheduler.Schedule(func(ctx context.Context) {
		check_if_complete(kommitID, s)
	}, chrono.WithStartTime(kDate.Year(), kDate.Month(), kDate.Day(), kDate.Hour(), kDate.Minute(), kDate.Second()))

}

func check_if_complete(kommitID string, s Store) {
	s.CheckIfComplete(kommitID)
}
