package models

func (s Store) GetOrganization(orgID string) (*Organization, error) {
	org := &Organization{}
	result := s.db.Where("OrganizationID =?", orgID).Find(org)
	if result.Error != nil {
		return nil, result.Error
	}

	return org, nil
}
