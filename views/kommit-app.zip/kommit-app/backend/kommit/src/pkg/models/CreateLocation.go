package models

import "time"

func (s Store) CreateUserLocation(loc *Location) error {
	loc.Date = time.Now()
	err := s.db.Create(&loc).Error
	if err != nil {
		return err
	}
	return nil
}
