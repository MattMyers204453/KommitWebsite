package models

import (
	"fmt"
	"log"
	"net/http"
	"net/url"
	"os"
)

func (s Store) CheckIfComplete(kommitID string) error {

	k := &Kommit{}
	result := s.db.Where("KommitID =?", kommitID).Find(k)
	if result.Error != nil {
		return result.Error
	}

	u := &User{}
	result2 := s.db.Where("UserID =?", k.UserID).Find(u)
	if result2.Error != nil {
		return result2.Error
	}
	userDeviceToken := u.DeviceToken

	data := url.Values{
		"kid":         {kommitID},
		"deviceToken": {userDeviceToken},
	}
	_, exists := os.LookupEnv("PAYPAL_ADDRESS")
	if !exists {
		os.Setenv("PAYPAL_ADDRESS", "https://kommit-paypal-server.herokuapp.com/push")
	}
	resp, err := http.PostForm(os.Getenv("PAYPAL_ADDRESS"), data) //_, err := http.PostForm("http://localhost:3000/push", data)

	if err != nil {
		log.Fatal(err)
	}

	fmt.Println(resp)

	fmt.Println("---- TELLING SERVER TO SEND PUSH NOTIFICATION")

	/*
		k := &Kommit{}
		result := s.db.Where("KommitID =?", kommitID).Find(k)
		//TODO: If not found throw error
		if result.Error != nil {
			return result.Error
		}

		fmt.Print("---- THE KOMMIT IS NOW DUE. CHECKING FOR COMPLETTION FOR KID: ")
		fmt.Println(k.KommitID)

		if !k.Completed {
			fmt.Println("---- FAILED KOMMIT. CHARGING CARD")
			ChargeCard()
		} else {
			fmt.Println("---- COMPLETED KOMMIT. THE CARD WILL NOT BE CHARGED")
		}
	*/

	return nil
}
