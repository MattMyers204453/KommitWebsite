package models

import "fmt"

// GetKommits returns all commits
func (s Store) GetKommits(userID string) []Kommit {

	fmt.Println(s.db)
	var Kommits []Kommit
	s.db.Find(&Kommits)
	result := s.db.Where("UserID =?", userID).Find(&Kommits)
	if result.Error != nil {
		panic(result.Error)
	}
	return Kommits
}
