package models

import "time"

func (s Store) CheckTime(currentTime time.Time, kommitTime time.Time) bool {
	return kommitTime.After(currentTime)
}
