package models

func (s Store) DeleteKommit(userID, kommitID string) *Kommit {
	kommit := &Kommit{}
	s.db.Where("KommitID=? AND UserID=?", kommitID, userID).Delete(kommit)

	return kommit
}
