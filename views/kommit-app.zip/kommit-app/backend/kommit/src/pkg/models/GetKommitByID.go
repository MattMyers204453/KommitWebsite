package models

func (s Store) GetKommitbyID(userID, kID string) (*Kommit, error) {
	k := &Kommit{}
	result := s.db.Where("KommitID =? AND UserID =?", kID, userID).Find(k)
	//TODO: If not found throw error
	if result.Error != nil {
		return nil, result.Error
	}

	return k, result.Error
}
