package models

import (
	"errors"

	"github.com/google/uuid"
)

type AuthorizedTokens struct {
	Tokens map[string]string
}

func (a AuthorizedTokens) GenerateToken(userID string) string {
	//make a guid
	token := string(uuid.NewString())
	a.Tokens[token] = userID
	return token
}

func (a AuthorizedTokens) GetID(token string) (string, error) {
	if userID, ok := a.Tokens[token]; ok {
		return userID, nil
	}
	return "", errors.New("invalid token")
}

func (a AuthorizedTokens) DeleteToken(token string) error {
	if _, ok := a.Tokens[token]; ok {
		delete(a.Tokens, token)
		return nil
	}
	return errors.New("token does not exist")
}
func (a AuthorizedTokens) Seed() {
	a.Tokens["fff7ee3b-b2b6-4ca7-a83c-e29e58d5b684"] = "42c30e55-8154-11ec-a92c-d85ed30193f8"
}
