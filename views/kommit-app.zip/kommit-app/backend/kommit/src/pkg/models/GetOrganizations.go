package models

// GetOrganizations returns all organizations in the database
func (s Store) GetOrganizations() ([]Organization, error) {

	var orgs []Organization
	err := s.db.Find(&orgs).Error
	if err != nil {
		return nil, err
	}
	return orgs, nil
}
