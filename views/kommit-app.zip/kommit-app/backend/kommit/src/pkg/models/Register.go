package models

import (
	"fmt"
)

func (s Store) Register(u *User) (*User, error) {

	// NEED TO HASH PASSWORD
	//HANDLE ERRORS IF USER IS CREATE
	// POSSIBLE MODIFY TABLE TO HANDLE

	err := s.db.Create(&u).Error

	if err != nil {
		return nil, err
	}
	fmt.Println(u)
	return u, nil
}
