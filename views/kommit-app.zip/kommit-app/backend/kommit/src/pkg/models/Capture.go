package models

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"

	"log"
	"net/url"
	"strconv"
)

func (s Store) Capture(kid string) error {

	k := &Kommit{}
	result := s.db.Where("KommitID =?", kid).Find(k)
	if result.Error != nil {
		return result.Error
	}
	bet := strconv.Itoa(k.Bet)

	u := &User{}
	result2 := s.db.Where("UserID =?", k.UserID).Find(u)
	if result2.Error != nil {
		return result2.Error
	}
	userPaymentMethodID := u.PaypalInfo
	//fmt.Println("paymentID: " + userPaymentMethodID)

	data := url.Values{
		"bet":                 {bet},
		"userPaymentMethodID": {userPaymentMethodID},
	}

	fmt.Println("---Attempting to hit capture paypal endpoint...")
	_, exists := os.LookupEnv("PAYPAL_ADDRESS")
	if !exists {
		os.Setenv("PAYPAL_ADDRESS", "https://kommit-paypal-server.herokuapp.com/push")
	}
	resp, err := http.PostForm(os.Getenv("PAYPAL_ADDRESS"), data) //resp, err := http.PostForm("http://localhost:3000/capture", data)

	if err != nil {
		log.Fatal(err)
	}

	var res map[string]interface{}

	json.NewDecoder(resp.Body).Decode(&res)

	return nil
}
