package models

import (
	"fmt"
	"kommit/src/pkg/config"
	"time"

	"gorm.io/gorm"
)

type Store struct {
	db *gorm.DB
}

type User struct {
	Username    string `gorm:"column:Username" json:"username"`
	UserID      string `gorm:"column:UserID" json:"user_id"`
	First       string `gorm:"column:First" json:"first"`
	Last        string `gorm:"column:Last" json:"last"`
	Address     string `gorm:"column:Address" json:"address"`
	Phone       string `gorm:"column:Phone" json:"phone"`
	Password    string `gorm:"column:Password" json:"password"`
	Role        int    `gorm:"Role" json:"role"`
	PaypalInfo  string `gorm:"column:PaypalID" json:"PaypalMethodID"`
	DeviceToken string `gorm:"column:DeviceToken" json:"devicetoken"`
}

type Kommit struct {
	KommitID        string  `gorm:"column:KommitID" json:"kommit_id"`
	Date            string  `gorm:"column:Date" json:"date"`
	LocationName    string  `gorm:"column:LocationName" json:"location_name"`
	Latitude        float64 `gorm:"column:Latitude" json:"latitude"`
	Longitude       float64 `gorm:"column:Longitude" json:"longitude"`
	Bet             int     `gorm:"column:Bet" json:"bet"`
	OrganizationID  string  `gorm:"column:OrganizationID" json:"organization_id"`
	UserID          string  `gorm:"column:UserID" json:"user_id"`
	Name            string  `gorm:"column:Name" json:"name"`
	Component       int     `gorm:"column:Component" json:"component"`
	DaysOfTheWeek   int     `gorm:"column:DaysOfTheWeek" json:"days_of_the_week"`
	Duration        int     `gorm:"column:Duration" json:"duration"`
	NumberOfSuccess int     `gorm:"column:NumberOfSuccess" json:"number_of_sucess"`
}
type Location struct {
	Latitude  float64   `gorm:"column:Latitude" json:"latitude"`
	Longitude float64   `gorm:"column:Longitude" json:"longitude" `
	Date      time.Time `gorm:"column:Time" json:"date"`
	UserID    string    `gorm:"column:UserID" json:"user_id"`
}

type Organization struct {
	OrganizationID string `gorm:"column:OrganizationID" json:"organization_id"`
	Label          string `gorm:"column:Label" json:"label"`
	PayPalEmail    string `gorm:"column:PayPalEmail" json:"paypal_email"`
}

type Token struct {
	Token  string `gorm:"column:Token" json:"token"`
	UserID string `gorm:"column:UserID" json:"user_id"`
}

type PaypalInfo struct {
	PaypalInfo string `gorm:"column:PaypalInfo" json:"PaypalMethodID"`
	UserID     string `gorm:"column:UserID" json:"user_id"`
}

func NewStore() Store {
	db := config.Connect()
	db.AutoMigrate(&Kommit{})
	fmt.Println(db)
	return Store{db}
}

func (s Store) GetAllUsers() []User {

	var Users []User
	s.db.Find(&Users)

	return Users
}
