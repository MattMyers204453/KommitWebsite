package models

import (
	"errors"

	"golang.org/x/crypto/bcrypt"
)

func (s Store) Login(username string, password string, devicetoken string) (string, error) {
	u := &User{}
	// result := s.db.Raw("SELECT password FROM Users where Username=?", username)
	result := s.db.Where("Username =?", username).Find(u)

	if result.Error != nil {
		return "", result.Error
	}

	err := bcrypt.CompareHashAndPassword([]byte(u.Password), []byte(password))

	if err != nil {
		return "", errors.New("incorrect username or password")
	}

	res := s.db.Model(&User{}).Where("UserID=?", u.UserID).Update("DeviceToken", devicetoken)

	if res.Error != nil {
		return "", res.Error
	}

	return u.UserID, nil
}
