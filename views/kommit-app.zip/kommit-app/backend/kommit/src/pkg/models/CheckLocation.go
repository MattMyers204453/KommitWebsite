package models

import "math"

func (s Store) CheckLocation(lat1, lon1, lat2, lon2 float64) bool {
	return math.Abs(lat1-lat2) < 0.01 && math.Abs(lon1-lon2) < 0.01
}
