package models

func (s Store) UpdateSucess(kommitID string) error {
	k := &Kommit{}
	s.db.Where("kommitID =?", kommitID).Find(k)
	result := s.db.Model(&Kommit{}).Where("kommitID =?", kommitID).Update("NumberOfSuccess", k.NumberOfSuccess+1)

	if result.Error != nil {
		return result.Error
	}

	return result.Error

}
