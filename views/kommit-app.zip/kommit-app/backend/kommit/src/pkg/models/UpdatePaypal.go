package models

import "fmt"

func (s Store) UpdatePaypal(p *PaypalInfo) error {

	fmt.Print("USERID: " + p.UserID)
	fmt.Print("PAYPALID: " + p.PaypalInfo)
	result := s.db.Model(&User{}).Where("UserID=?", p.UserID).Update("PaypalID", p.PaypalInfo)

	if result.Error != nil {
		panic(result.Error)
	}
	return result.Error
}
