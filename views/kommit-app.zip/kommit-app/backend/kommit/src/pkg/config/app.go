package config

import (
	"fmt"
	"os"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

func Connect() *gorm.DB {
	_, exists := os.LookupEnv("DB_ADDRESS")
	if !exists {
		os.Setenv("DB_ADDRESS", "mysql-kommit.cyu9jckte1cr.us-east-1.rds.amazonaws.com")
	}
	_, exists = os.LookupEnv("DB_USER")
	if !exists {
		os.Setenv("DB_USER", "admin")
	}
	dsn := os.Getenv("DB_USER") + ":" + os.Getenv("DB_PASSWORD") + "@tcp(" + os.Getenv("DB_ADDRESS") + ")/Capstone?charset=utf8mb4&parseTime=True&loc=Local"
	d, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		panic(err)
	}
	fmt.Println("Successfully connected to: " + os.Getenv("DB_ADDRESS"))
	return d

}
