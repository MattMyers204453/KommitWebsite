-- MySQL dump 10.13  Distrib 8.0.28, for macos11 (x86_64)
--
-- Host: mysql-kommit.cyu9jckte1cr.us-east-1.rds.amazonaws.com    Database: Capstone
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `kommits`
--

DROP TABLE IF EXISTS `kommits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kommits` (
  `KommitID` varchar(36) NOT NULL,
  `Date` datetime NOT NULL,
  `LocationName` varchar(65) NOT NULL,
  `Latitude` double NOT NULL,
  `Longitude` double NOT NULL,
  `Bet` int NOT NULL,
  `OrganizationID` varchar(36) NOT NULL,
  `UserID` varchar(36) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Component` int NOT NULL,
  `Duration` int NOT NULL,
  `DaysOfTheWeek` int NOT NULL,
  `NumberOfSuccess` int DEFAULT '0',
  PRIMARY KEY (`KommitID`,`OrganizationID`,`UserID`),
  KEY `fk_Kommits_Users1_idx` (`UserID`),
  KEY `fk_Kommits_Organizations1_idx` (`OrganizationID`),
  CONSTRAINT `fk_Kommits_Organizations1` FOREIGN KEY (`OrganizationID`) REFERENCES `organizations` (`OrganizationID`),
  CONSTRAINT `fk_Kommits_Users1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kommits`
--

LOCK TABLES `kommits` WRITE;
/*!40000 ALTER TABLE `kommits` DISABLE KEYS */;
INSERT INTO `kommits` VALUES ('0dc160c8-3fe1-464f-9361-fb5b20645c62','2022-04-14 03:09:15','AMC Loews Layton Hills 9',41.0818608,-111.9790787,4,'027A16EE-8158-11EC-A92C-D85ED30193F8','fb80b997-f57c-436b-bfcd-2d2cadf66467','stu',0,0,0,1),('15642b36-6c60-43b6-9639-7388cfcdb2c0','2022-04-14 06:06:00','Guerrero',17.7329097,-99.9673736,5,'0285F3FE-8158-11EC-A92C-D85ED30193F8','13bf577f-67a6-454e-8723-d21da8de46ea','grond',0,0,0,0),('1847c9e5-9f87-4a67-968b-a9b42f8760ee','2022-04-14 03:42:34','G.O.A.T. Haircuts - Layton',41.08973859299246,-111.97453916072845,2,'0284A8CD-8158-11EC-A92C-D85ED30193F8','fb80b997-f57c-436b-bfcd-2d2cadf66467','l',0,0,0,1),('1e10ff90-20bd-4013-99ce-7db23f1eeb97','2022-04-14 03:16:03','R & J',30.4404255,-97.6105087,5,'0284A8CD-8158-11EC-A92C-D85ED30193F8','fb80b997-f57c-436b-bfcd-2d2cadf66467','tcv',0,0,0,0),('2f061e95-71b9-454a-86dc-f11af8cd68f2','2022-04-14 03:44:23','Garcia\'s',41.0760394,-111.9744935,2,'0284A8CD-8158-11EC-A92C-D85ED30193F8','fb80b997-f57c-436b-bfcd-2d2cadf66467','k',0,0,0,1),('3a469be6-496e-4aa5-8ca7-8f2cff2978e2','2022-04-14 17:48:00','Fox Creek',41.0846807,-111.9718188,5,'0285F3FE-8158-11EC-A92C-D85ED30193F8','795d686e-d133-4954-9939-0819fbbdccf8','g',0,0,0,0),('42df0953-1527-4653-ac79-5a3ee568086c','2022-04-14 04:26:36','J&J Nursery and Garden Center',41.05929133898409,-112.0001757144928,6,'0284A8CD-8158-11EC-A92C-D85ED30193F8','4cc66482-aba9-48aa-a0dc-0388313c22c9','f',0,0,0,0),('4aeafc5d-61f9-474a-accb-07f6e6251ee9','2022-04-14 05:03:00','Starbucks',41.08718737225521,-111.98047757148743,2,'0284A8CD-8158-11EC-A92C-D85ED30193F8','a82f277d-2d28-45c2-800a-3f18f2395b51','tt',0,0,0,1),('502ae847-ca78-47d7-922e-9115c7b9fd68','2022-04-21 22:14:00','HPER North',40.76394463480962,-111.840383952441,7,'0285F3FE-8158-11EC-A92C-D85ED30193F8','3ec3f413-21c1-4aec-a90a-0a2c832c00b0','',0,0,0,0),('5ad22750-bf8f-4a38-a774-62e140c0dc6c','2022-04-14 04:23:59','D St',41.0471056,-111.9519358,5,'0285F3FE-8158-11EC-A92C-D85ED30193F8','c59546d6-0793-4fd5-9cf2-b5fc25a49cf9','g',0,0,0,0),('5d163fd4-95d0-4e42-8e2e-9b071fbe1b99','2022-04-14 03:10:58','AMC Loews Layton Hills 9',41.0818608,-111.9790787,8,'0284A8CD-8158-11EC-A92C-D85ED30193F8','fb80b997-f57c-436b-bfcd-2d2cadf66467','s',0,0,0,1),('5dac9a1b-6a5f-475f-9520-0ed34e18b625','2022-04-14 04:33:18','Lee\'s Mongolian BBQ',41.2128781,-111.9702417,2,'0284A8CD-8158-11EC-A92C-D85ED30193F8','aac812f5-50ea-4337-b980-075cb8f41e95','r',0,0,0,0),('689f76c0-b495-4c20-84ea-5cad9b344e67','2022-04-14 04:47:00','Seminole Hard Rock Hotel & Casino',27.9928777,-82.3723738,2,'0285F3FE-8158-11EC-A92C-D85ED30193F8','2f61cbf7-e708-415e-907d-8557d1fe1b22','yhg',0,0,0,0),('6d04671d-0698-4552-95c3-b4e0fd41690c','2022-04-14 05:32:04','Starbucks',41.08718737225521,-111.98047757148743,2,'0285F3FE-8158-11EC-A92C-D85ED30193F8','72ed8c68-4087-44ba-aea3-20260154a3c9','g',0,0,0,1),('70ad1173-c982-48db-86bd-f96e6b54a252','2022-04-14 03:30:09','W Mortensen Ln',40.2442069,-109.99770307649261,2,'027A16EE-8158-11EC-A92C-D85ED30193F8','fb80b997-f57c-436b-bfcd-2d2cadf66467','h',0,0,0,0),('7619559e-8159-11ec-a92c-d85ed30193f8','2022-01-29 12:30:00','Moms place',40.76531309,22.838211957,20,'027a16ee-8158-11ec-a92c-d85ed30193f8','42c30e55-8154-11ec-a92c-d85ed30193f8','Visit Mom',1,14,1,0),('7dabc591-815c-11ec-a92c-d85ed30193f8','2022-01-29 12:30:00','Gym',41.76531309,27.838211957,20,'0284a8cd-8158-11ec-a92c-d85ed30193f8','42c30e55-8154-11ec-a92c-d85ed30193f8','Workout',0,0,1,0),('8012a4f2-7702-45b0-b180-3e165342e9f6','2022-04-14 02:58:00','J&J Nursery and Garden Center',41.05929133898409,-112.0001757144928,2,'0285F3FE-8158-11EC-A92C-D85ED30193F8','fb80b997-f57c-436b-bfcd-2d2cadf66467','jjjjjj',0,0,0,0),('b7a5cdb0-0cb6-46c0-a7ec-268cf5fac846','2022-04-14 02:45:00','Club V Sports',40.8409409,-111.9456143,4,'0285F3FE-8158-11EC-A92C-D85ED30193F8','1a7774fc-04c4-4a62-b870-16fa9c1a08d5','ghjip',0,0,0,0),('c822749e-0d00-4116-a288-1203444e8214','2022-04-14 03:08:17','R & J',30.4404255,-97.6105087,2,'0284A8CD-8158-11EC-A92C-D85ED30193F8','fb80b997-f57c-436b-bfcd-2d2cadf66467','r',0,0,0,0),('f0b95ff3-29ae-463b-8860-5c29aa423f74','2022-04-14 04:37:00','Big O Tires',41.0795731,-111.9892134,6,'0284A8CD-8158-11EC-A92C-D85ED30193F8','0a9e2e26-6cdd-45af-b7da-f81629233cfd','f',0,0,0,0),('f236f6cd-6cd1-4cc3-9bc2-9a62890a8d10','2022-04-14 04:56:00','R & J',30.4404255,-97.6105087,2,'0284A8CD-8158-11EC-A92C-D85ED30193F8','325c39b2-cdad-4448-b4c6-5547212bab2e','f',0,0,0,0),('f9b3557c-815b-11ec-a92c-d85ed30193f8','2022-01-29 12:30:00','Carl jr',33.76531309,57.838211957,20,'0284a8cd-8158-11ec-a92c-d85ed30193f8','42c30e55-8154-11ec-a92c-d85ed30193f8','Eat',1,8,3,0);
/*!40000 ALTER TABLE `kommits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `Latitude` varchar(36) NOT NULL,
  `Longitude` double NOT NULL,
  `Time` datetime NOT NULL,
  `UserID` varchar(36) NOT NULL,
  PRIMARY KEY (`UserID`,`Time`),
  KEY `fk_User_Location_Users1_idx` (`UserID`),
  CONSTRAINT `fk_User_Location_Users1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES ('41.084735579827154',-111.97150382223722,'2022-04-14 04:35:38','0a9e2e26-6cdd-45af-b7da-f81629233cfd'),('41.08469225059387',-111.97144099398305,'2022-04-14 06:06:01','13bf577f-67a6-454e-8723-d21da8de46ea'),('41.08470390708438',-111.97147565904096,'2022-04-14 02:44:46','1a7774fc-04c4-4a62-b870-16fa9c1a08d5'),('41.08465993315103',-111.97147322829065,'2022-04-14 04:46:58','2f61cbf7-e708-415e-907d-8557d1fe1b22'),('41.0846918262926',-111.97136702957746,'2022-04-14 04:54:47','325c39b2-cdad-4448-b4c6-5547212bab2e'),('40.76531309',50.76531309,'2022-01-29 11:30:00','42b56c98-8154-11ec-a92c-d85ed30193f8'),('33.76531309',57.838211957,'2022-01-29 12:30:00','42c00c4f-8154-11ec-a92c-d85ed30193f8'),('41.084672799372406',-111.97142159576711,'2022-04-14 04:21:57','4cc66482-aba9-48aa-a0dc-0388313c22c9'),('41.08471730727825',-111.97138329046962,'2022-04-14 05:32:05','72ed8c68-4087-44ba-aea3-20260154a3c9'),('41.08472807802383',-111.97139443840084,'2022-04-14 05:03:01','a82f277d-2d28-45c2-800a-3f18f2395b51'),('41.08462594453367',-111.97154028351602,'2022-04-14 04:19:23','c59546d6-0793-4fd5-9cf2-b5fc25a49cf9'),('41.0847835360749',-111.97144353132404,'2022-04-14 20:58:01','f032969e-7178-441f-9909-e04a3beaefc7'),('41.08469652933495',-111.97143802703985,'2022-04-14 02:56:34','fb80b997-f57c-436b-bfcd-2d2cadf66467'),('41.084612575398126',-111.97142863656578,'2022-04-14 03:03:39','fb80b997-f57c-436b-bfcd-2d2cadf66467'),('41.0846757446376',-111.97139907774017,'2022-04-14 03:04:34','fb80b997-f57c-436b-bfcd-2d2cadf66467'),('41.08459778133901',-111.9715034869611,'2022-04-14 03:06:19','fb80b997-f57c-436b-bfcd-2d2cadf66467'),('41.084646103010805',-111.9714894891828,'2022-04-14 03:13:44','fb80b997-f57c-436b-bfcd-2d2cadf66467'),('41.084611904845865',-111.97145235735175,'2022-04-14 03:25:50','fb80b997-f57c-436b-bfcd-2d2cadf66467'),('41.084590279535675',-111.97145571011302,'2022-04-14 03:38:16','fb80b997-f57c-436b-bfcd-2d2cadf66467'),('41.08462757900458',-111.97146275091168,'2022-04-14 03:39:43','fb80b997-f57c-436b-bfcd-2d2cadf66467');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizations` (
  `OrganizationID` varchar(36) NOT NULL,
  `Label` varchar(45) NOT NULL,
  `PayPalEmail` varchar(45) NOT NULL,
  PRIMARY KEY (`OrganizationID`),
  UNIQUE KEY `PayPalEmail_UNIQUE` (`PayPalEmail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES ('027a16ee-8158-11ec-a92c-d85ed30193f8','Make a Wish','makeawish@paypal.com'),('0284a8cd-8158-11ec-a92c-d85ed30193f8','Salvation Army','salvationarmy@paypal.com'),('0285f3fe-8158-11ec-a92c-d85ed30193f8','Breast Cancer','breastcancer@paypal.com');
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `UserID` varchar(36) NOT NULL,
  `First` varchar(45) NOT NULL,
  `Last` varchar(45) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Phone` varchar(45) NOT NULL,
  `Password` varchar(10000) NOT NULL,
  `Role` int NOT NULL,
  `Username` varchar(65) NOT NULL,
  `PaypalID` varchar(45) DEFAULT NULL,
  `DeviceToken` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Username_UNIQUE` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('0a9e2e26-6cdd-45af-b7da-f81629233cfd','','','','','$2a$04$LQ/.mK17M6MB3yWR4NV6P.YmE6JaMbVaPoW4mr84bAt42rGnu.Ary',0,'fghj@jjj.brb','','14ef0aaea6f8f7dafc595f473b63cbe02d9ea1d8fcf16c818ac698377ab03efb'),('13bf577f-67a6-454e-8723-d21da8de46ea','','','','','$2a$04$ktytPgcCbpSg/fRO171S8udT3xXewH89daQyGSQn7gyaXa/XYvpuq',0,'okm@nbv.j','cGF5bWVudG1ldGhvZF9wcF9rN2NqbjVn','a4d85d911409352e0c70c8f3c48817c63be931566de4e5b8a603ef67370df5bf'),('1a7774fc-04c4-4a62-b870-16fa9c1a08d5','','','','','$2a$04$3Jk9Iqnf2hcjZYEfKka3XeGb42qGgSMoX1WwkPsYg9CRN4qGSwN3a',0,'ddddd@dddd.dddd','','5a29b365bfea574c6043197452ec4cb99cf6f98acf1569ddaf170a17209448ec'),('2a1f094b-9bbd-4592-8f4b-1841d89bbcfe','','','','','$2a$04$E2fKlnfXfphRzsz2MXI5m.eky.DGMsbEaGIzqA8hhoCEXpzWbR.Qq',0,'old@cghn.no','','70211e0cfbca6f3095f367160bd634449023085f77fc1ab04e02b4c914612279'),('2d15b835-cf28-46ad-908a-e9213647ce05','','','','','$2a$04$ujQOIuPjX6HRvjl2USCb1.8KG/MI82wVMrTEynnpflmAGh0iyW.Ca',0,'hi@hj.no','cGF5bWVudG1ldGhvZF9wcF9ndm5mdHM2','ed59e1edb9f7e7d5adf093abeb9cbf25f7bcf1177d529fc736204c1316fc8baf'),('2f61cbf7-e708-415e-907d-8557d1fe1b22','','','','','$2a$04$hdi8iTmGhoVy.K/7zcElX.28YPtqxC9spao0Xsuk.hZ1MBZLeS3wa',0,'hghghf@yhgf.bank','','344ee30732e194652c7f0926779eb1a48f658869988ef97d7e9dfe41247d09ff'),('325c39b2-cdad-4448-b4c6-5547212bab2e','','','','','$2a$04$gbZpnvYNYJBWui49Vewjo..R7wvb9sRsR7t.yQ1otto/XcXuY3tbO',0,'jkoi@nj.no','','797dad69f2b7632a50ed762beee9d4ce3b73615fff43b9f60ef5ddadf14f2bc3'),('3ec3f413-21c1-4aec-a90a-0a2c832c00b0','','','','','$2a$04$.L/HSpFAlh5gfX/4lDoiiOhoSFWpUMsnOrJvW13l5dNf75RkhAXPG',0,'asdf@ttt.fff','cGF5bWVudG1ldGhvZF9wcF9kZmtnZjRi',''),('42b56c98-8154-11ec-a92c-d85ed30193f8','Carlos','Neira','350 S 600 E','719-373-8797','$2a$04$j/wwRXB3rt.vPP3C/XUnleZCe2xNZ7CQjnzVKG3im26uD45d.drMG',1,'carlos@test.com','paypalID',NULL),('42c00c4f-8154-11ec-a92c-d85ed30193f8','Jordan','Hendley','345 W 34 E','721-345-6575','$2a$04$j/wwRXB3rt.vPP3C/XUnleZCe2xNZ7CQjnzVKG3im26uD45d.drMG',0,'jordan@test.com','paypalID',NULL),('42c16b99-8154-11ec-a92c-d85ed30193f8','Matt','Myers','345 W 34 E','123-455-5644','$2a$04$j/wwRXB3rt.vPP3C/XUnleZCe2xNZ7CQjnzVKG3im26uD45d.drMG',0,'matt@test.com','paypalID',NULL),('42c30e55-8154-11ec-a92c-d85ed30193f8','Jeremy','Cruz','345 W 34 E','234-677-6788','$2a$04$j/wwRXB3rt.vPP3C/XUnleZCe2xNZ7CQjnzVKG3im26uD45d.drMG',0,'test@test.com','cGF5bWVudG1ldGhvZF9wcF9kbmhrcTZt','5289f1c6d73016322af2f4c2105e9385ccc506088b7683d5612de5505b352173'),('4cc66482-aba9-48aa-a0dc-0388313c22c9','','','','','$2a$04$OzyIO5SCqafPiqo6KzwBy..qJKdOP/106rbwbu2bf43MD0hG4we0y',0,'pujgfd@jnhgf.gggg','','89e24c4b3fd26901942feb5a63e2e2d438cd8d7218ca25981fff3ebc667ecbbe'),('72ed8c68-4087-44ba-aea3-20260154a3c9','','','','','$2a$04$tll1yMNHKoRxLEywcIIbOueCZRQmImo66ENDcFHw6J0TQJw7b2J6W',0,'pppppp@pp.pp','','5c36db4ae7f55099fd6ad329ec8b5bff2704a3cce59e5689d82983184b82c2e0'),('795d686e-d133-4954-9939-0819fbbdccf8','','','','','$2a$04$KFCv/NgUIUxN9ZyP8P2ITevABhlYBZr1mbkU/I.BZTExTMwUToht2',0,'sasasa@sasa.dada','cGF5bWVudG1ldGhvZF9wcF9idGp4bjM2','3d80ccb33e98ead9f84de1a6abd73f46fa49bfed218d95b540443ca70fe4ad37'),('90e2e339-e0ec-42d8-a3f5-2d3068174e7f','','','','','$2a$04$jY6Ano2g/sjPH4oHCutznubnIMb/r4eQzZA8HTR3GhklNEMaiLrBG',0,'rtyui@uhn.bcc','','4d07e592b4f747fab80fa8e8fc7414a91b73a9c94ea5070f5f8fe210212a925c'),('a82f277d-2d28-45c2-800a-3f18f2395b51','','','','','$2a$04$e0br8qThxjvhmI57PQhhLOpCIgKD5Jp6VbQC3wuY9AMSmEiQ.KjRG',0,'fg@nj.bb','','966e1dfd0dac8bbf9b5ac13ba80965ddbe084053107a4eaaa538b88742378d34'),('aac812f5-50ea-4337-b980-075cb8f41e95','','','','','$2a$04$8b45ATAmLiBHh.AJkTCzc.3HnOg3Df92tHu/.TaAcK1QnxZe0f25K',0,'cccc@ccc.cc','','1c63b0172fb951359762efa1d619bb89f89cfd9cecd0a148ab4e70c179b577b7'),('b0dcd475-e2fa-4894-becf-d031e41b89cf','','','','','$2a$04$/cWcEBwiguklayEsmkal0eOuMiBh7D/QGgMKs1MkEkbhhbQSICLzq',0,'ghk@nnnnn.brb','','11ef01f83a562ed2b153f6803366abf9b6445d9fc6f4da4d3cd0c621e9b1fab8'),('c59546d6-0793-4fd5-9cf2-b5fc25a49cf9','','','','','$2a$04$S0xIaXwKlw1u.jVqGYjSa.xd8WI2MIIpPAgJuZHfqkyZPr.hHOzFy',0,'lllll@llll.lll','','ab0c719217ae87d9771ce609ae4de76fa522e4c0752d6e60cafa36a52d555e5b'),('c9f9045a-4651-410e-bf37-313d5adbae1c','','','','','$2a$04$NnJLLby2x7fqZcU/HNX9.OQdBUCIxKnQj4aqRXBjQuHptQIGNvoaG',0,'thujj@nnn.mm','','74e42c5f02ef0e3de836878d4c203bdbd4cfc4b191302f18680fbed7a703ab7c'),('ec04ffb6-c04d-4fd1-be7b-366f4312b958','','','','','$2a$04$M1H5ghWEWqK024Xi03OWs.5Z524QU/Bbt7aRgetrwEtgsg38qgTUe',0,'aaaaa@aaaa.asa','','2f1a51b13814a85e87040c752f6e8c840119976b4e9eff8cc82f2bda43161e72'),('f032969e-7178-441f-9909-e04a3beaefc7','','','','','$2a$04$OwY.HSUjy4okY.jInHWIFevgz3lFFDySeIkFCFSuSoPBOxlqeZY2O',0,'jordan.hendley@gmail.com','cGF5bWVudG1ldGhvZF9wcF9uNHY1aG42','1fd8b3d157a0af2f491925e45a7354f97df8a53ae6d8df77749490b31baad638'),('fb80b997-f57c-436b-bfcd-2d2cadf66467','','','','','$2a$04$Byw7KxpbWdukA9QuQiK/aOwosNxqJcbqBeIK8AMxMx9pi4iuWadQq',0,'jjjjjj@jjjj.jjj','','9ea0b37a47f13192b5570bce0e2f2b4a72fde3633bdadd2a436db531b335bb38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-15 20:59:18
