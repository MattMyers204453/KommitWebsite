package main

import (
	"fmt"
	"kommit/src/pkg/controllers"
	"kommit/src/pkg/routes"
	"log"
	"net/http"
	"os"

	"github.com/gorilla/mux"
	_ "github.com/jinzhu/gorm/dialects/mysql"
)

func main() {
	fmt.Println("Starting Server")
	r := mux.NewRouter()
	c := controllers.NewController()
	routes.RegisterRoutes(r, c)
	http.Handle("/", r)
	_, exists := os.LookupEnv("GATEWAY_PORT")
	if !exists {
		os.Setenv("GATEWAY_PORT", "8080")
	}
	log.Fatal(http.ListenAndServe("0.0.0.0:"+os.Getenv("GATEWAY_PORT"), r))

}
