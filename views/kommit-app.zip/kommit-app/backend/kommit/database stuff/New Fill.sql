
use Capstone;
-- UserID, First, Last, Address, Phone, Password, Role, Username
insert into users values('42b56c98-8154-11ec-a92c-d85ed30193f8', "Carlos", "Neira", "350 S 600 E", "719-373-8797", "$2a$04$j/wwRXB3rt.vPP3C/XUnleZCe2xNZ7CQjnzVKG3im26uD45d.drMG",1, "carlos@test.com", "paypalID", NULL);
insert into users values('42c00c4f-8154-11ec-a92c-d85ed30193f8', "Jordan", "Hendley", "345 W 34 E", "721-345-6575", "$2a$04$j/wwRXB3rt.vPP3C/XUnleZCe2xNZ7CQjnzVKG3im26uD45d.drMG", 0, "jordan@test.com", "paypalID", NULL );
insert into users values('42c16b99-8154-11ec-a92c-d85ed30193f8', "Matt", "Myers", "345 W 34 E", "123-455-5644", "$2a$04$j/wwRXB3rt.vPP3C/XUnleZCe2xNZ7CQjnzVKG3im26uD45d.drMG", 0, "matt@test.com", "paypalID", NULL);
insert into users values('42c30e55-8154-11ec-a92c-d85ed30193f8', "Jeremy", "Cruz", "345 W 34 E", "234-677-6788", "$2a$04$j/wwRXB3rt.vPP3C/XUnleZCe2xNZ7CQjnzVKG3im26uD45d.drMG", 0, "test@test.com", "paypalID", NULL);

insert into organizations values( '027a16ee-8158-11ec-a92c-d85ed30193f8', "Make a Wish", "makeawish@paypal.com" );
insert into organizations values( '0284a8cd-8158-11ec-a92c-d85ed30193f8', "Salvation Army", "salvationarmy@paypal.com" );
insert into organizations values( '0285f3fe-8158-11ec-a92c-d85ed30193f8', "Breast Cancer", "breastcancer@paypal.com" ); 


							-- KommitID,                            Date,                  LocationName, Latitude,   Longitude,   Bet, OrganizationID,                         UserID,                                 Name, Component, Duration, DaysOfTheWeek
insert into kommits values('7619559e-8159-11ec-a92c-d85ed30193f8', '2022-01-29 12:30:00', 'Moms place', 40.76531309, 22.838211957, 20,'027a16ee-8158-11ec-a92c-d85ed30193f8', '42c30e55-8154-11ec-a92c-d85ed30193f8', 'Visit Mom', 1, 14, 1, 0);
insert into kommits values('7dabc591-815c-11ec-a92c-d85ed30193f8', '2022-01-29 12:30:00', 'Gym', 41.76531309, 27.838211957, 20, '0284a8cd-8158-11ec-a92c-d85ed30193f8',  '42c30e55-8154-11ec-a92c-d85ed30193f8', 'Workout', 0,0,1, 0);
insert into kommits values('f9b3557c-815b-11ec-a92c-d85ed30193f8', '2022-01-29 12:30:00', 'Carl jr', 33.76531309, 57.838211957, 20, '0284a8cd-8158-11ec-a92c-d85ed30193f8', '42c30e55-8154-11ec-a92c-d85ed30193f8', 'Eat', 1, 8,3, 0);

select * from kommits;


insert into locations values(40.76531309, 50.76531309, '2022-01-29 11:30:00', '42b56c98-8154-11ec-a92c-d85ed30193f8');
insert into locations values(33.76531309, 57.838211957, '2022-01-29 12:30:00', '42c00c4f-8154-11ec-a92c-d85ed30193f8');

select * from locations;
select * from users;
select * from kommits

drop database capstone;